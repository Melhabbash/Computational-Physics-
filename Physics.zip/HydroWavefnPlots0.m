% Plot the first few radial wavefunctions for the hydrogen atom with l=0
% (no angular momentum).

x=[0:.02:5];
y = zeros(6,251);

for n=0:5
    y(n+1,:) = -exp(-x) .* polyval(LaguerrePoly(n),x);
end

figure;
plot(x,y(1,:),x,y(2,:),x,y(3,:),x,y(4,:),x,y(5,:),x,y(6,:)),
    xlabel('\rho'),...
    ylabel('R_{n,0}(\rho)'),title('Hydrogen Radial Wavefunctions; n\leq 5, l=0')
h = legend('n=0', 'n=1', 'n=2', 'n=3', 'n=4', 'n=5', 4);
grid on;
