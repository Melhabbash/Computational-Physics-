% Plot the first few radial wavefunctions for the hydrogen atom with l=2.

x=[0:.05:10];
y = zeros(5,201);

for n=2:5
    y(n,:) = -x.^2 .* exp(-x) .* polyval(AssociatedLaguerrePoly(n,2),x);
end

figure;
plot(x,y(2,:),x,y(3,:),x,y(4,:),x,y(5,:)),
    xlabel('\rho'),...
    ylabel('R_{n,2}(\rho)'),title('Hydrogen Radial Wavefunctions; n\leq 5, l=2')
h = legend('n=2', 'n=3', 'n=4', 'n=5', 4);
grid on;
