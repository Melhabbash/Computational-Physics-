This directory contains MATLAB files for 1D simulations of electromagnetic fields. 
Included are wave propagation in free space, in dissipative media (sigma nonzero),
and in dispersive media (debye medium).