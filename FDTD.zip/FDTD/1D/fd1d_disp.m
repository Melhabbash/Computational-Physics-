%  fd1d_disp.m
%
%  This is the code for Chapter 2, Section 1.
%
%  This is a 1D EM simulation with a dielectric. 
%  We have a hard Gaussian source.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see p.13 of the text.

KE = 200;                        % Number of grid points.
dx = zeros(KE,1);                % Electric flux density.
ex = zeros(KE,1);                % Electric field vector. 
ix = zeros(KE,1);                % Parameter vector.
hy = zeros(KE,1);                % Magnetic field vector.
kc = KE/2;                       % Center of computational domain.

% Input dielectric constant vector and location of dielectric. 
epsilon_0 = 8.85419e-12;         % Permittivity of free space.
epsilon_r = 4; %input('Enter the permittivity epsilon_r = '); 
epsilon_r_vec = ones(KE,1);
dstart = kc; %input('Enter the starting point of the dielectric: ');
epsilon_r_vec(dstart:KE) = epsilon_r*epsilon_r_vec(dstart:KE);

% Input the conductivity. Ohmic conductivity: J = sigma*E.
sigma = .00; %input('Enter the conductivity sigma = ');
sigma_vec = zeros(KE,1);
sigma_vec(dstart:KE) = sigma_vec(dstart:KE) + sigma;                       

% To simulate a metal back boundary
sigma_vec(KE) = 1e6;             % This corresponds to high conductivity.

% Determine step sizes ddx and dt.
disp('WARNING: REMEMBER THAT THE STEP SIZES ARE PROBLEM DEPENDENT!!!')
freq_in_MHz = 500;               % Frequency in megahertz.
freq_in = 1e6*freq_in_MHz;           
ddx = .03;                    % Cell size. Eqn. (1.19). Here 1cm = .01.
dt = ddx/6e8;                    % Calculate the time step size, Eqn. (1.7).

% Determine recursion vectors. See (1.23) and (1.24) in the text.
gbx = (dt*sigma_vec)./epsilon_0;
gax = 1./(epsilon_r_vec + gbx);

% Pulse information.
pulse_choice = input('Enter 1 for Gaussian, 2 for sine wave pulse: ');
if pulse_choice == 1
  t0 = 50;                        % Center of incident pulse.
  stdev = 10;                     % Std. deviation of gaussain pulse.
else
  cut_off = 1; %input('Enter number of sine wave cycles: ');
  cut_off = cut_off/(freq_in*dt);  
  if ceil(cut_off) ~= cut_off      % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
end

% Initialize variables.
T = 0;                           % Initialize time step.
NSTEPS = 1000;                   % Number of time steps.
save_ex1 = zeros(3,1);           % Storage vector for ABC.  
save_ex2 = zeros(3,1);           % Storage vector for ABC.  

% Main FDTD loop.

for n = 1:NSTEPS

  T = T + 1;

  % Given the necessary H field values, determine the Dx field.
  for k = 2:KE
     dx(k) = dx(k) + .5*(hy(k-1) - hy(k));
  end 
 
  % Generate the electric pulse.
  if pulse_choice == 1
   pulse = exp(-.5*((t0-T)/stdev)^2);
  elseif T < cut_off
    pulse = sin(2*pi*freq_in*dt*T);
  else
    pulse = 0;
  end
  dx(5) = dx(5) + pulse;

  % Calculate Ex and Ix from Dx.
  for k = 1:KE-1
     ex(k) = gax(k) * (dx(k)-ix(k));
     ix(k) = ix(k) + gbx(k) * ex(k);
  end  

  % Save info for absorbing boundary condition.
  save_ex1(2:3) = save_ex1(1:2);
  save_ex1(1) = ex(2);
%  save_ex2(2:3) = save_ex2(1:2);
%  save_ex2(1) = ex(KE-1);

  % Absorbing Boundary Condition.
  ex(1) = save_ex1(3);             % Left boundary condition.
%  ex(KE) = save_ex2(3);            % Right boundary condition.

  % Given the necessary E field values, determine the H field.
  for k = 1:(KE-1)
     hy(k) = hy(k) + .5*(ex(k)-ex(k+1));
  end

%  Ex{n} = ex;
%  Hy{n} = hy;

%  disp('Hit any key to continue.')
%  pause

  figure(1)
     subplot(211)
       plot(ex)
       title('Electric Field')
     subplot(212)
       plot(hy)  
       title('Magnetic Field')

end
