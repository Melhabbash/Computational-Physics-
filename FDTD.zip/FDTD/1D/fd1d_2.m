%  fd1d_2.m
%
%  This is a 1D EM simulation in free space. 
%  We have two hard Gaussian sources.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see p.13 of the text.

KE = 200;                        % Number of grid points.
ex = zeros(200,1);               % Electric field vector. 
hy = zeros(200,1);               % Magnetic field vector.
kc = KE/2;                       % Center of computational domain.
t0 = 40;                         % Center of incident pulse.
sigma = 12;                      % Std. deviation of gaussain pulse.

T = 0;
NSTEPS = 1000;

% Main FDTD loop.

for n = 1:NSTEPS

  T = T + 1;

  % Given the necessary H field values, determine the E field.
  for k = 2:KE
     ex(k) = ex(k) + .5*(hy(k-1)-hy(k));
  end 
 
  % Put in two Gaussian pulses.
  pulse = exp(-.5*((t0-T)/sigma)^2);
  ex(kc-20) = pulse;
  ex(kc+20) = pulse;

  % Given the necessary E field values, determine the H field.
  for k = 1:(KE-1)
     hy(k) = hy(k) + .5*(ex(k)-ex(k+1));
  end

  figure(1)
    plot(ex)
    title('Electric Field')

end
