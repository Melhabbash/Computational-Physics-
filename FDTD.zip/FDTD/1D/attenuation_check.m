% attenuation.m
%
% Check the attenuation of the electric field.
% Use equation (1.A.6).
%
z = [0:1/KE:1-1/KE]';                   % Spacial discretization.
E_0 = 1;                        % Amplitude of sine wave.

omega = 2*pi*freq_in;

alpha = (omega/3e8)*sqrt(.5*epsilon_r_vec).*...
           sqrt(sqrt(1+(sigma_vec./(omega.*epsilon_0.*epsilon_r_vec)).^2)-1);

figure(2)
     subplot(211)
       kk = exp(-alpha.*z);
       kk(kc:KE) = kk(kc:KE)/kk(kc);
       kk(1:kc-1) = -1;
       plot(kk)
       
     subplot(212)
       plot(ex)
