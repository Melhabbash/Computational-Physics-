%  fd1d_abc.m
%
%  For Chapter 1, Section on absorbing boundary conditions.
%
%  This is a 1D EM simulation in free space. 
%  We have a hard Gaussian source.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see p.13 of the text.

KE = 500;                        % Number of grid points.
ex = zeros(KE,1);                % Electric field vector. 
hy = zeros(KE,1);                % Magnetic field vector.
kc = 10;                       % Center of computational domain.
t0 = 40;                         % Center of incident pulse.
sigma = 12;                      % Std. deviation of gaussain pulse.
alpha = .5;                      % Parameter for ex, hy recursion.

T = 0;                           % Initialize time step.
NSTEPS = 10000;                    % Number of time steps.
E_readings = zeros(NSTEPS,1);
save_ex1 = zeros(3,1);           % Storage vector for ABC.  
save_ex2 = zeros(3,1);           % Storage vector for ABC.  

% Main FDTD loop.

for n = 1:NSTEPS

  T = T + 1;

  % Given the necessary H field values, determine the E field.
  for k = 2:KE
     ex(k) = ex(k) + alpha*(hy(k-1)-hy(k));
  end 
 
  % Put a Gaussian pulse in the middle
  if T <= 200 
    pulse = sin((pi/100)*T);%exp(-.5*((t0-T)/sigma)^2);
  else
    pulse = 0;
  end
  ex(10) = ex(10) + pulse;
  E_readings(10) = ex(10);

  % Save info for absorbing boundary condition.
  save_ex1(2:3) = save_ex1(1:2);
  save_ex2(2:3) = save_ex2(1:2);
  save_ex1(1) = ex(2);
  save_ex2(1) = ex(KE-1);

  % Absorbing Boundary Condition.
  ex(1) = save_ex1(3); 
  ex(KE) = save_ex2(3);

  % Given the necessary E field values, determine the H field.
  for k = 1:(KE-1)
     hy(k) = hy(k) + alpha*(ex(k)-ex(k+1));
  end

  if mod(T,20)==0
    figure(1)
      plot(ex)
      title('Electric Field')
      disp('Hit any key to continue.')
      pause
  end      
end
