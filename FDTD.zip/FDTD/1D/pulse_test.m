%  fd1d_abc.m
%
%  For Chapter 1, Section on absorbing boundary conditions.
%
%  This is a 1D EM simulation in free space. 
%  We have a hard Gaussian source.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see p.13 of the text.

KE = 200;                        % Number of grid points.
ddx = 1/200;
dt = ddx/6e8;
ex = zeros(KE,1);                % Electric field vector. 
hy = zeros(KE,1);                % Magnetic field vector.
kc = 10;                         % Center of computational domain.
t0 = 40;                         % Center of incident pulse.
sigma = 12;                      % Std. deviation of gaussain pulse.
alpha = .5;                      % Parameter for ex, hy recursion.

%------------------------------------------------------------------------
% Pulse information.
%------------------------------------------------------------------------
pulse_choice = input('Enter 1 for Gaussian, 2 for sine wave pulse: ');
if pulse_choice == 1
  t0 = 20;                       % Center of incident pulse.
  stdev = 6;                    % Std. deviation of gaussain pulse.
else
  freq_in_MHz = 1800;            % Frequency in megahertz.
  freq_in = 1e6*freq_in_MHz;           
  cut_off = 2; %input('Enter number of sine wave cycles: ');
  cut_off = cut_off/(freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
end



T = 0;                           % Initialize time step.
NSTEPS = 200;                    % Number of time steps.
save_ex1 = zeros(3,1);           % Storage vector for ABC.  
save_ex2 = zeros(3,1);           % Storage vector for ABC.  

% Main FDTD loop.

for n = 1:NSTEPS

  T = T + 1;

  % Given the necessary H field values, determine the E field.
  for k = 2:KE
     ex(k) = ex(k) + alpha*(hy(k-1)-hy(k));
  end 
 
  % Put a Gaussian pulse in the middle
  if pulse_choice == 1 & T <  2*t0 - 1
    pulse = exp(-.5*((t0-T)/stdev)^2);
    ex(kc) = ex(kc) + pulse;
  elseif pulse_choice == 2 & T < cut_off
    pulse = sin(2*pi*freq_in*dt*T);
    ex(kc) = ex(kc) + pulse;
  end

  % Save info for absorbing boundary condition.
  save_ex1(2:3) = save_ex1(1:2);
  save_ex2(2:3) = save_ex2(1:2);
  save_ex1(1) = ex(2);
  save_ex2(1) = ex(KE-1);

  % Absorbing Boundary Condition.
  ex(1) = save_ex1(3); 
  ex(KE) = save_ex2(3);

  % Given the necessary E field values, determine the H field.
  for k = 1:(KE-1)
     hy(k) = hy(k) + alpha*(ex(k)-ex(k+1));
  end

  figure(1)
    plot(ex)
    title('Electric Field')

  figure(2)
     plot(fftshift(real(fft(ex))))
end

