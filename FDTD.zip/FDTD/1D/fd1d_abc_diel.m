%  fd1d_abc_diel.m
%
%  Code for Chapter 1, dielectric section.
%
%  This is a 1D EM simulation with a dielectric. 
%  We have a hard Gaussian source.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see p.13 of the text.

KE = 200;                        % Number of grid points.
ex = zeros(KE,1);                % Electric field vector. 
hy = zeros(KE,1);                % Magnetic field vector.
kc = KE/2;                       % Center of computational domain.

% Input the conductivity. Ohmic conductivity: J = sigma*E.
sigma = .04;
sigma_vec = zeros(KE,1);
sigma_vec(kc:KE) = sigma_vec(kc:KE) + sigma;                       

% Input dielectric constant vector 
epsilon_0 = 8.85419e-12;         % Permittivity of free space.
cb = .5*ones(KE,1);              
epsilon_r = 4;                   % Dielectric constant.
%cb(kc:KE) = cb(kc:KE)/epsilon_r; 

% Determine step sizes ddx and dt.
disp('WARNING: REMEMBER THAT THE STEP SIZES ARE PROBLEM DEPENDENT!!!)
freq_in_MHz = 400;               % Frequency in megahertz.
freq_in = 1e6*freq_in_MHz;           
ddx = .01;                       % Compute cell size using equation (1.19),
                                 % where 1cm = .01;
dt = ddx/(2*3e8);                % Calculate the time step size, Eqn. (1.7).

% Determine recursion vectors. See (1.23) and (1.24) in the text.
eaf = (dt*sigma)/(2*epsilon_0*epsilon_r);
ca = (1-eaf)/(1+eaf);
cb = .5/(epsilon*(1+eaf));

% Pulse information.
%t0 = 40;                         % Center of incident pulse.
%stdev = 12;                      % Std. deviation of gaussain pulse.
cut_off = 2;                     % Number of sine wave cycles.
cut_off = cut_off/(freq_in*dt);  
if ceil(cut_off) ~= cut_off      % Equal if freq_in_MHZ*ddx divides 3e8.
  disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
end

% Initialize variables.
T = 0;                           % Initialize time step.
NSTEPS = 1000;                   % Number of time steps.
save_ex1 = zeros(3,1);           % Storage vector for ABC.  
save_ex2 = zeros(3,1);           % Storage vector for ABC.  

% Main FDTD loop.

for n = 1:NSTEPS

  T = T + 1;

  % Given the necessary H field values, determine the E field.
  for k = 2:KE
     ex(k) = ex(k) + cb(k)*(hy(k-1)-hy(k));
  end 
 
  % Pulse
  %pulse = exp(-.5*((t0-T)/stdev)^2);
  if T < cut_off
    pulse = sin(2*pi*freq_in*dt*T);
  else
    pulse = 0;
  end
  ex(5) = ex(5) + pulse;

  % Save info for absorbing boundary condition.
  save_ex1(2:3) = save_ex1(1:2);
  save_ex2(2:3) = save_ex2(1:2);
  save_ex1(1) = ex(2);
  save_ex2(1) = ex(KE-1);

  % Absorbing Boundary Condition.
  ex(1) = save_ex1(3);             % Left boundary condition.
%  ex(KE) = save_ex2(3);            % Right boundary condition.

  % Given the necessary E field values, determine the H field.
  for k = 1:(KE-1)
     hy(k) = hy(k) + .5*(ex(k)-ex(k+1));
  end

%  Ex{n} = ex;
%  Hy{n} = hy;

%  disp('Hit any key to continue.')
%  pause

  figure(1)
     subplot(211)
       plot(ex)
       title('Electric Field')
     subplot(212)
       plot(hy)  
       title('Magnetic Field')

end
