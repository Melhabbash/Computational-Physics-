  function[gi1,gi2,gi3,gj1,gj2,gj3,fi2,fi3,fj2,fj3] = get_pml(KE)

%  This m-file creates the necessary PML vectors and parameters.

% Initialize PML vectors.
fi2 = ones(KE,1);
fi3 = ones(KE,1);
gi1 = zeros(KE,1);
gi2 = ones(KE,1);
gi3 = ones(KE,1);
fj2 = ones(KE,1);
fj3 = ones(KE,1);
gj1 = zeros(KE,1);
gj2 = ones(KE,1);
gj3 = ones(KE,1);

pml_choice = 1;%input('Enter 1 for PMLs; 0 otherwise: ');
if pml_choice == 1
  %------------------------------------------------------------------------
  % Determine PML parameters.
  %------------------------------------------------------------------------
  npml_x = 20;% input('Enter the number of PML cells in x-directions: ');
  for i= 0:npml_x
    xnum = npml_x - i;
    % D_z
    xxn = xnum/npml_x;
    xn = .333*xxn^3;
    gi1(i+1) = xn;
    gi1(KE-i) = xn;
    gi2(i+1) = 1/(1+xn); 
    gi2(KE-i) = 1/(1+xn); 
    gi3(i+1) = (1-xn)/(1+xn);
    gi3(KE-i) = (1-xn)/(1+xn); 
    % for H_x and H_y
    xxn = (xnum - .5)/npml_x;
    xn = .333*xxn^3;
    fi2(i+1) = 1/(1+xn);
    fi2(KE-1-i) = 1/(1+xn); 
    fi3(i+1) = (1-xn)/(1+xn);
    fi3(KE-1-i) = (1-xn)/(1+xn); 
  end

  npml_z = 20;% input('Enter the number of PML cells in z-direction: '); 
  for j = 0:npml_z
    xnum = npml_z - j;
    % D_z
    xxn = xnum/npml_z;
    xn = .333*xxn^3;
    gj1(j+1) = xn;
    %gj1(KE-j) = xn;
    gj2(j+1) = 1/(1+xn); 
    %gj2(KE-j) = 1/(1+xn); 
    gj3(j+1) = (1-xn)/(1+xn);
    %gj3(KE-j) = (1-xn)/(1+xn); 
    % for H_x and H_y
    xxn = (xnum - .5)/npml_z;
    xn = .333*xxn^3;
    fj2(j+1) = 1/(1+xn);
    %fj2(KE-1-j) = 1/(1+xn); 
    fj3(j+1) = (1-xn)/(1+xn);
    %fj3(KE-1-j) = (1-xn)/(1+xn); 
  end
end
