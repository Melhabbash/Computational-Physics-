  function[pulse] = get_pulse(KE,dt)

%------------------------------------------------------------------------
% Get electric pulse information.
%------------------------------------------------------------------------
pulse.choice = input('Enter 1 for Gaussian, 2 for sine wave pulse: ');
if pulse.choice == 1
  pulse.t0 = 20;                       % Center of incident pulse.
  pulse.stdev = 6;                    % Std. deviation of gaussain pulse.
  % Cutoff pulse when the pulse value is less than its T=1 value.
  pulse.cut_off = 2*pulse.t0;
else
  freq_in_MHz = 3000;            % Frequency in megahertz.
  pulse.freq_in = 1e6*freq_in_MHz;           
  cut_off = 3; %input('Enter number of sine wave cycles: ');
  pulse.cut_off = cut_off/(pulse.freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
  pulse.dt = dt;
end
pulse.amplitude = 1;%input('Enter the amplitude of the sine wave: ');

% Antenna location.
la = input('Enter z-coord of antenna location: ');
da = KE/10; %%input('Enter the width of antenna: ');
kc = KE/2;
pulse.I = [la*KE + kc - da/2 : la*KE + kc + da/2];
