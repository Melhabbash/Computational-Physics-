% rn1.m

for i = 1:4
  fprintf('OUTER ITERATION = %d\n',i)
  x_true(3) = 68.75 + (i-1)*5;
  E_true = E_function(x_true,cost_params);
  E{i} = E_true;
end
