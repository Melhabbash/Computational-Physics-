  function[p] = dogleg_cnstr(A,g,pg,p,W,TR_radius)
%
%  Compute the dogleg solution to the TR subproblem
%

  % Incorporate constraints
  
  alpha = (pg'*g)/(pg'*A*pg);

  if alpha^2*pg'*W*pg > TR_radius
    alpha = sqrt(TR_radius/(pg'*W*pg));
    p = -alpha*pg;

  else  

    % Compute the dogleg solution. Use the quadratic formula.
    cp = -alpha*pg;
    v = p - cp;
    a = v'*W*v;
    b = 2*v'*W*cp;
    c = cp'*W*cp - TR_radius;
    beta = (-b + sqrt(b^2 - 4*a*c))/2*a;
    p = cp + beta*v;

  end

  %fprintf(' TR_radius=%3.3e |p|=%3.3e pWp=%5.5e\n',TR_radius,norm(p),p'*W*p)
