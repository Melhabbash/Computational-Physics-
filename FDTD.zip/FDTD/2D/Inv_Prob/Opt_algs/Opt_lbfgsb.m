%  L-BFGS-B matlab/mex interface for Nocedal's code.
%
%  MATLAB driver for Nocedal's lbfgs-b fortran code.
%
%---------------------------------------------------------------------------
%  Cost Function and parameters.
%  NOTE: Run Setup to generate cost_params.
%---------------------------------------------------------------------------
  cost_fn                  = 'TM_function';
  cost_params.cost_fn      = cost_fn;
  cost_params.h            = sqrt(eps);                   % For finite difference. 

%---------------------------------------------------------------------------
% Scalar parameters needed.
%---------------------------------------------------------------------------
  n         = prod(size(x_true));   % Number of unknowns.
  m         = input(' Input number of bfgs vectors stored. '); 
  nmax      = n; 
  mmax      = m;
  iprint    = 1;                    % Frequency of output generated.  
  factr     = 0;                    % Stopping criteria.
  pgtol     = 1e-1;                 % Stopping criteria.
  
%---------------------------------------------------------------------------
% Vectors and function/gradient evaluation needed.  
%---------------------------------------------------------------------------
  xold      = zeros(n,1);           
  xold(1)   = 1.5e-5; %x_true(1);
  xold(2)   = 1/(10e-12*3e8); %x_true(2);
  xold(3)   = 73.1;  %x_true(3);
  xold(4)   = 10;
  [fold,gold] = feval(cost_fn,xold,cost_params);
  l = -1e16*ones(n,1);              % Lower bound vector.
%  l(2) = 1;
%  l(3) = 60;
%  l(4) = 2.5
  u = 1e16*ones(n,1);                   % Upper bound vector.
  u(1) = 1e-2;
  u(2) = 1e-4;
  u(3) = 90;
  u(4) = 7.5;
  nbd = ones(n,1);                  % Tells code which bounds.

%---------------------------------------------------------------------------
% Character strings needed.
%---------------------------------------------------------------------------
  task='START';
  csave = 'temp';

%---------------------------------------------------------------------------
% Arrays used within lbfgs_b fortran code.
%---------------------------------------------------------------------------
  wa    = zeros((2*mmax+4)*nmax+12*mmax^2+12*mmax,1);   % Workspace.
  iwa   = zeros(3*nmax,1);                              % Workspace.
  lsave = zeros(4,1); lsave = logical(lsave);           % Data vector.
  isave = zeros(44,1);                                  % Data vector.
  dsave = zeros(29,1);                                  % Data vector.

%---------------------------------------------------------------------------
%  Initialize cpu time.                                        %
%---------------------------------------------------------------------------
  cpu_t0 = cputime;

%---------------------------------------------------------------------------
% Begin iteration.
%---------------------------------------------------------------------------
  iter = 0;

  while iter == 0 | strcmp(task(1:2),'FG') | strcmp(task(1:5),'NEW_X')
    
    iter = iter + 1;
    
   % Call to lbfgs-b.
    [xnew,wa,iwa,task,csave,lsave,isave,dsave] = setulb(n,m,xold,...
l,u,nbd,fold,gold,factr,pgtol,wa,iwa,task,iprint,csave,lsave,isave,dsave);

   % Function evaluation.
    if strcmp(task(1:2),'FG')
      [fnew,gnew] = feval(cost_fn,xnew,cost_params);
      xold = xnew;
      fold = fnew;
      gold = gnew;
    end

      fprintf('iter=%d sigma=%5.5e tau=%5.5e eps_s=%5.5e eps_infty=%5.5e\n',iter,xold(1),1/(3e8*xold(2)),xold(3),xold(4))
    
  end


  

