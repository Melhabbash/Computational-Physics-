  function[p] = dogleg(A,g,p,W,TR_radius)
%
%  Compute the dogleg solution to the TR subproblem
%

  % Incorporate constraints
  
  alpha = (g'*g)/(g'*A*g);

  if alpha^2*g'*W*g > TR_radius
    alpha = sqrt(TR_radius/(g'*W*g));
    p = -alpha*g;

  else  

    % Compute the dogleg solution. Use the quadratic formula.
    cp = -alpha*g;
    v = p - cp;
    a = v'*W*v;
    b = 2*v'*W*cp;
    c = cp'*W*cp - TR_radius;
    beta = (-b + sqrt(b^2 - 4*a*c))/2*a;
    p = cp + beta*v;

  end

  %fprintf(' TR_radius=%3.3e |p|=%3.3e pWp=%5.5e\n',TR_radius,norm(p),p'*W*p)
