  function[p] = nearly_exact(A,g,W,TR_radius)
%
%  Compute the nearly exact solution to the trust region sub problem.
%  We follow Algorithm 4.4 in Nocedal, Wright. That is, we see to solve
%
%                      phi(lambda) = 0,
%
%  where phi(lambda) = 1/TR_radius - 1/||(A+lambda*I)\g||_W. 
%  W is a weighting matrix.
%

  I = eye(size(A));

  lambda = 1000000;
  l_tol = 1e-15;
  n_iters = 5;
  flag = 1;
  i = 0;

  while flag == 1 
    i = i + 1;
    x = (A+lambda*I)\g;
    xWx = x'*W*x;
    l = 1/xWx - 1/(TR_radius^2);
    if abs(l) <= l_tol
      p = -x;
      return
    end   
    W_p = (A+lambda*I)\W;
    lp = (2*x'*W_p*x)/(xWx^2);
    lambda = lambda - l/lp;
    if lambda <= 0
      disp(' Lambda parameter not positive!!! ')
    end
    %fprintf('i=%d lambda=%5.5e l=%5.5e lp=%5.5e\n',i,lambda,l,lp)
  end

  
