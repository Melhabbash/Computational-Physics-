  function[p] = nearly_exact(A,g,W,TR_radius)
%
%  Compute the nearly exact solution to the trust region sub problem.
%  We follow Algorithm 4.4 in Nocedal, Wright. That is, we see to solve
%
%                      phi(lambda) = 0,
%
%  where phi(lambda) = 1/TR_radius - 1/((A+lambda*I)\g).
%

  [Q,D] = svd(A);
  w = Q*g;
  I = eye(size(Q));

  lambda = 1;
  n_iters = 20;

  for i = 1:n_iters
    D = inv(D + lambda*I)^2;
    D_hat = -2*inv(D + lambda*I)^3;
    l = w'*D*w - TR_radius^2;
    lp = w'*D_hat*w;
    lambda = lambda - l/lp;
fprintf('i=%d lambda=%5.5e l=%5.5e lp=%5.5e\n',i,lambda,l,lp)
  end

  p = -inv(A+lambda*I)*g;
