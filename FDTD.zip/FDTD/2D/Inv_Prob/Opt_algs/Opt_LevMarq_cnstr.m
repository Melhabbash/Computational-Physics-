% Opt_LevMarq.m
%
% An implementation of the Levenberg-Marquardt Algorithm 
% as found in Nocedal and Wright's, "Numerical Optimization".
%
%---------------------------------------------------------------------------
%  Cost Function and parameters.
%  NOTE: Run Setup to generate cost_params.
%---------------------------------------------------------------------------
  cost_fn                  = 'TM_function';
  cost_params.cost_fn      = cost_fn;
  cost_params.h            = sqrt(eps);                   % For finite difference. 
  opt_vars                 = cost_params.opt_vars;
  p_fn                     = 'dogleg_cnstr';
  x                        = ones(4,1);           
  x(1)                     = 1.5e-5;                      % Initial guesses.
  x(2)                     = 1/(10e-12*3e8);%1/(7.233e-12*3e8); 
  x(3)                     = 73.1;%80.1;  
  x(4)                     = 10;%5.5;
  Constraint               = [0 0 1 1]';
  Active                   = (x == Constraint);
  [J , E, g, A]            = feval(cost_fn,x,cost_params);
  pg                       = ((1-Active)+(g<0).*Active).*g;

  fprintf('iter=%d sigma=%3.3e tau=%3.3e eps_s=%3.3e eps_infty=%3.3e\n',0,x(1),1/(3e8*x(2)),x(3),x(4))
  fprintf('       J=%2.2e |pg|=%2.2e |s|=%2.2e TR_radius=%2.2e rho=%2.2e\n',J,norm(pg),0,0,0)     
%---------------------------------------------------------------------------
%  Initialize necessary parameters.                                        %
%---------------------------------------------------------------------------
  cpu_t0 = cputime;
  eta = .1;                                       % Update parameter.
  W = eye(max(size(x)));                          % Scaling matrix.
  if opt_vars(1) == 1
    W(1,1)    = 1e5;
  end
  if opt_vars(2) == 1
    W(2,2)    = 1e-2;
  end
  if opt_vars(3) == 1
    W(3,3)    = 1e-1;
  end
  if opt_vars(4) == 1   
    W(4,4)    = 1;
  end
  TR_max    = 1000;
  TR_radius = max(min((g'*W*g)/(g'*W*A*g),TR_max),1); % Initial TR radius.
  data      = cost_params.data;
  nd_sq   = norm(data)^2;

%---------------------------------------------------------------------------
% Begin iteration.
%---------------------------------------------------------------------------
  flag = 1;
  iter = 0;
  pcompute = 0;

  while flag == 1
    
    iter = iter + 1;

    p = - A\g;    %% THIS NEEDS TO CHANGE TO REFLECT THE PAPER.
    
    % Incorporate constraints. Notice that this just projects the dogleg
    % path onto the constraints.
    p = ((1-Active)+(p>0).*Active).*p; %% THIS NEEDS TO CHANGE TO REFLECT THE PAPER.
    pg = ((1-Active)+(g<0).*Active).*g;
    
    % Check to see if step is within the trust region. If not compute new p.
    if p'*W*p > TR_radius
      pcompute = 1;
      p = feval(p_fn,A,g,pg,p,W,TR_radius);
    end

    % Evaluate the function, gradient, Jacobian.
    x_test = x + p;
    x_test = max(x_test,Constraint); % Incorporate constraints.
    [J_test, E_test, g_test, A_test] = feval(cost_fn,x_test,cost_params);

    % Check the efficacy of the projected Gauss-Newton approximation.
    % Compute rho = [J(x) - J(x+p)]/[m(0)-m(p)], where
    % m(p) is the Gauss-Newton quadratic approx. of J at x.
    rho_num = J - J_test;
    rho_denom = -p'*g - .5*p'*A*p;

    if sign(rho_num) == -1 & sign(rho_denom) == -1
      disp(' WARNING: Increase in J and in quadratic approximation to J. ')
      rho = -1;
    else
      rho = (J - J_test)/(-p'*g - .5*p'*A*p); 
    end

    % Update TR_radius (see Algorithm 4.1 in Nocedal and Wright).
    if rho < .25
      TR_radius = .25*TR_radius;
    elseif rho > .75 & pcompute == 1
      pcompute = 0;
      TR_radius = min(2*TR_radius,TR_max);    
    end

    % Determine whether or not to accept update
    if rho > eta
      snorm = (x-x_test)'*W*(x-x_test);
      E = E_test;
      x = x_test;
      Active = (x == Constraint);
      J = J_test;
      g = g_test;
      A = A_test;
    else
      disp(' Update skipped. ')
      snorm = 0;
    end

    fprintf('iter=%d sigma=%3.3e tau=%3.3e eps_s=%3.3e eps_infty=%3.3e\n',iter,x(1),1/(3e8*x(2)),x(3),x(4))
    fprintf('       J=%2.2e |pg|=%2.2e |s|=%2.2e TR_radius=%2.2e rho=%2.2e\n',J,norm(pg),snorm,TR_radius,rho)     

    if 0%iter == 350 %| norm(g) < 1e-2
      flag = 0;
    end

  end


  
