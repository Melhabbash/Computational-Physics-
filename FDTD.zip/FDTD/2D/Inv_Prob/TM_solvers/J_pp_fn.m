% J_pp_fn.m
%
% Computes the second derivative with respect to epsilon_s
%

x_hat = input(' x_hat = ');

J = input(' J_hat = '); %feval(cost_fn,x_hat,cost_params);
disp(' First function evaluation done. ')
h = 1e-4;%cost_params.h;
x_m_h = x_hat;
x_m_h(3) = x_m_h(3) - h;  
J_m_h = feval(cost_fn,x_m_h,cost_params);
disp(' Second function evaluation done. ')
x_p_h = x_hat;
x_p_h(3) = x_p_h(3) + h;
J_p_h = feval(cost_fn,x_p_h,cost_params);
disp(' Third function evaluation done. ')

J_pp = (1/stdev^2)*(J_m_h -2*J + J_p_h)/h^2

