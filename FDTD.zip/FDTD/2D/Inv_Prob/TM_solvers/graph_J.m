% graph_J.m
%
% We wish to graph the function J.
% We know that epsilon_s = 80.1 and 
% we want to graph it in this area.

delta_x = .1;  

x_hat = input(' x_hat = ');

J = feval(cost_fn,x_hat,cost_params);

N = 10;

xx = [-N*delta_x:delta_x:N*delta_x];

yy = zeros(size(xx));

yy(N+1) = J;

xtemp = x_hat;

for i = 1:N

  xtemp(3) = x_hat(3) + xx(N + 1 + i);
  yy(N + 1 + i) = feval(cost_fn,xtemp,cost_params);

  xtemp(3) = x_hat(3) - xx(N + 1 - i);
  yy(N + 1 - i) = feval(cost_fn,xtemp,cost_params);
 
  figure(1)
    plot(xx(N + 1 - i : 1 : N + 1 + i),yy(N + 1 - i : 1 : N + 1 + i))
    pause(0.1)
     

end
