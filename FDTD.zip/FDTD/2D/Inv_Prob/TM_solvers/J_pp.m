% J_pp.m
%
% Computes the second derivative with respect to epsilon_s
%

J = feval(cost_fn,x,cost_params);
h = cost_params.h;
v = [0 0 1 0]';
x_m_h = x;
x_m_h(3) = x_m_h(3) + h;  
J_m_h = feval(cost_fn,x_m_h,cost_params);
x_p_h = x;
x_p_h(3) = x_p_h(3) + h;
J_p_h = feval(cost_fn,x_p_h,cost_params);

J_pp = (J_m_h -2*J + J_p_h)/h^2

