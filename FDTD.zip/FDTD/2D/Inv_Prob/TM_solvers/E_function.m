  function[ E_readings ] = E_function(x,cost_params)

%----------------------------------------------------------------------------
% Extract debye parameters from x.
%----------------------------------------------------------------------------
sigma         = x(1);                % x(1) = conductivity
if x(2) == 0
  tau_0 = 1e8;
else
  tau_0         = 1/(3e8*x(2));        % x(2) = 1/tau_0*c_0
end
epsilon_r     = x(4);                % x(4) = epsilon_infty
chi_1         = x(3) - x(4);         % x(3) = epsilon_s

%----------------------------------------------------------------------------
% Extract necessary parameters and vectors from cost_params.
%----------------------------------------------------------------------------
params        = cost_params.params;
Nx            = params.Nx;
Nz            = params.Nz;
NSTEPS        = params.NSTEPS;
Mstart        = params.Mstart;
dt            = params.dt;
f_pmls        = cost_params.f_pmls;
g_pmls        = cost_params.g_pmls;
pulse_params  = cost_params.pulse_params;
sample_rate   = cost_params.sample_rate;

%----------------------------------------------------------------------------
% Create necessary parameter vectors.
%----------------------------------------------------------------------------
epsilon_r_vec              = ones(Nx,Nz);    % Permittivity vector.
sigma_vec                  = zeros(Nx,Nz);   % Conductivity vector.
gbc                        = zeros(Nx,Nz);   

epsilon_r_vec(:,Mstart:Nz) = epsilon_r;            
sigma_vec(:,Mstart:Nz)     = sigma;                    
epsilon_0                  = 8.8e-12;                   % Permittivity of free space.
gb                         = (dt*sigma_vec)./epsilon_0; 
gbc(:,Mstart:Nz)           = (chi_1*dt/tau_0)/(1+.5*dt/tau_0);
ga                         = 1./(epsilon_r_vec + gb + gbc);              
const                      = (1-.5*dt/tau_0)/(1+.5*dt/tau_0);

% Ensure that at the PML boundaries Ey = 0 by setting appropriate ga values to 0.
% To model the perfect electrical conductor on the Z+ boundary, set ga(:,Nz) = 0. 
ga(1,:) = 0; 
ga(Nx,:) = 0;  
ga(:,1) = 0; 
ga(:,Nz) = 0;

%----------------------------------------------------------------------------
% Store the necessary vectors and parameters.
%----------------------------------------------------------------------------
medium_params.ga    = ga;
medium_params.gb    = gb;
medium_params.gbc   = gbc;
medium_params.const = const;

%----------------------------------------------------------------------------
% Evaluate the function J by first computing a forward solution.
%----------------------------------------------------------------------------

E_readings = TMsolver_mex(params,f_pmls,g_pmls,medium_params,pulse_params);

