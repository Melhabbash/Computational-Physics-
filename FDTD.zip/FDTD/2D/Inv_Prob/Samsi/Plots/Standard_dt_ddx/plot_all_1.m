% Plot the respective solutions.

figure(1)
p1280 = input(' Enter 1 to plot E_1280_320; 0 otherwise: ');
p640  = input(' Enter 1 to plot E_640_160; 0 otherwise: ');
p320  = input(' Enter 1 to plot E_320_80; 0 otherwise: ');
p160  = input(' Enter 1 to plot E_160_40; 0 otherwise: ');
p80  = input(' Enter 1 to plot E_80_20; 0 otherwise: ');
if p1280 == 1 
  load E_1280_320
  plot(E_1280_320,'b'), hold on
end
if p640 == 1
  load E_640_160
  plot(E_640_160,'r'), hold on
end
if p320 == 1
  load E_320_80
  plot(E_320_80,'g'), hold on  
end
if p160 == 1
  load E_160_40
  plot(E_160_40,'m')
end
if p80 == 1
  load E_80_20
  plot(E_80_20,'m')
end

hold off
