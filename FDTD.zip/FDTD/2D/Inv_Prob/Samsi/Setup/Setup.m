% Setup.m
%
% The purpose of this file is to setup the necessary parameters 
% for solving the inverse problem.
%  
%------------------------------------------------------------------------
% Geometry of problem.
%------------------------------------------------------------------------
%   x-axis ^  dielectric
%          |  interface    X+           E=0 supra-conductive boundary
%    ______|_____|_______________________|
%   |            pml                     | 
%   |      ______________________________|
%   |      |free |                       |  
%   |      |space|      dielectric       |
%   |      |     |                       |
% Z-| pml  |    computational region     |Z+
%   |      | *   |                       |
%   |      | antenna                     |
%   |      |     |                       |  
%   |   z=0 -----|---------------------z=Lz---> z-axis
%   |           z=z0      pml            |
%   |____________________________________|
%                          X-
%------------------------------------------------------------------------
%
k                    = .5;                          % To change the grid etc.
%------------------------------------------------------------------------
% Problem geometry and grid spacing.
%------------------------------------------------------------------------
Lz                    = .4;                        % Length of comp. region in z-dir.
Ml                    = .2;                        % Length of dispersive medium.
Nz                    = k*160;                     % Num. grid pts z-dir. (Need Lz/Nz int.)
Nx                    = k*40;                      % Num. grid pts x-dir. (Lx=Nx*(Lz/Nz))
ddx                   = Lz/Nz;                     % Grid spacing.
dt                    = ddx/6e8;                   % dt < 1e-12 for k>4.
if dt > ddx/(sqrt(2)*3e8)
  disp(' WARNING: Changing time step. Does not satisy CFL condition.')
  dt                    = ddx/6e8;  
end 
params.alpha          = (dt*3e8)/ddx;

%------------------------------------------------------------------------
% PML parameters.
%------------------------------------------------------------------------
npml_x                = k*20;                         % Num. pml grid pts. x-dir.
npml_z                = k*20;                         % Num. pml grid pts. x-dir.
pml_vec               = [1 1 0 1];                 % [X+ X- Z+ Z-]; where PMLs.

% Update Nx and Nz to account for PMLs and store.
Nx                    = Nx + (pml_vec(1) + pml_vec(2))*npml_x;
Nz                    = Nz + (pml_vec(3) + pml_vec(4))*npml_z;

[g_pmls,f_pmls] = get_pml(Nx,Nz,npml_x,npml_z,pml_vec);

%------------------------------------------------------------------------
% Input antenna and pulse parameters.
%------------------------------------------------------------------------
Az                      = k*40;                           % z-coord of antenna is Az*ddx.
pulse_params.Az         = npml_z + (Az - 1);            % Account for pml.
pulse_params.Aw         = k*20;                           % Antenna width. (divisible by 2)
pulse_params.Ac         = Nx/2;                         % Center of antenna.

choice                  = 2;     % 1 for Gaussian; 2 for sine wave.
pulse_params.choice     = choice;
pulse_params.amplitude  = 100;   % Pulse amplitude.
pulse_params.pulse_type = 1;     % 1 for additive pulse; 0 for hard pulse.
if choice == 1                   % Gaussian pulse.
  pulse_params.t0 = 20;          % Center of incident pulse.
  pulse_params.stdev = 6;        % Std. deviation of gaussain pulse.
  % Cutoff pulse when the pulse value is less than its T=1 value.
  cut_off               = 2*pulse_params.t0; % Truncation threshold
  pulse_params.cut_off  = cut_off;
else                             % Sine wave pulse
  freq_in_GHz = 3;               % Frequency in gigahertz
  pulse_params.freq_in = 1e9*freq_in_GHz;           
  cut_off = 2; %input('Enter number of sine wave cycles: ');
  cut_off = cut_off/(pulse_params.freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
  pulse_params.cut_off = ceil(cut_off);
end

%------------------------------------------------------------------------
% Store necessary information 
%------------------------------------------------------------------------
params.Nx                = Nx;
params.Nz                = Nz;

params.Mstart            = ceil((Lz-Ml)/ddx)+npml_z;  % z interface of medium.
params.dt                = dt;
NSTEPS                   = k*450;                 % # time steps: forward computation.
params.NSTEPS            = NSTEPS;
params.NINNER            = 100;%NSTEPS;                 % # time steps: fortran execution.
params.output            = 0;                   % 1 at each outer iteration; 0 otherwise.
cost_params.params       = params;
cost_params.g_pmls       = g_pmls;                    % PML info.
cost_params.f_pmls       = f_pmls;                    % PML info.
cost_params.pulse_params = pulse_params;              % Pulse info.
cost_params.opt_vars     = [0 0 1 0];                 % Variable to optimize.
sample_rate              = k*12;                      % Corresponds to .05 nanoseconds.
cost_params.sample_rate  = sample_rate;

%---------------------------------------------------------------------------
%  True parameter values for Debye medium. 
%---------------------------------------------------------------------------
x_true                   = zeros(4,1);
x_true(1)                = 1e-5;                 % Conductivity sigma.
x_true(2)                = 1/(8.1e-12*3e8);      % 1/(tau*c_0). 
%x_true(2)               = 8.1e-12;
x_true(3)                = 80.1;                 % epsilon_s = static permittivity.
x_true(4)                = 5.5;                  % epsilon_infty = high freq. permittivity

%---------------------------------------------------------------------------
%  Generate the data.
%---------------------------------------------------------------------------
%load E_160_40
%E_true = E_160_40;
%load E_320_80
%E_true = E_320_80;
%load E_640_160
%E_true = E_640_160;
%load E_1280_320
%E_true = E_1280_320;
E_true = E_function(x_true,cost_params);

prcnt_noise = input(' Input the percent noise: ');
ndata = max(size(E_true));
stdev = (norm(E_true)*prcnt_noise)/(sqrt(ndata)*100);
cost_params.E_true       = E_true;
cost_params.data         = E_true + stdev*randn(size(E_true));
