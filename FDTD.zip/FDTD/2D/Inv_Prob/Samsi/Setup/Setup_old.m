% Setup.m
%
% The purpose of this file is to setup the necessary parameters 
% for solving the inverse problem.
%  
%------------------------------------------------------------------------
% Geometry of problem.
%------------------------------------------------------------------------
%   x-axis ^  dielectric
%          |  interface    X+           Exn=0 boundary
%    ______|_____|_______________________|
%   |            pml                     | 
%   |      ______________________________|
%   |      |free |                       |  
%   |      |space|      dielectric       |
%   |      |     |                       |
% Z-| pml  |    computational region     |Z+
%   |      | *   |                       |
%   |      | antenna                     |
%   |      |     |                       |  
%   |   z=0 -----|---------------------z=Lz---> z-axis
%   |           z=z0      pml            |
%   |____________________________________|
%                          X-
%------------------------------------------------------------------------
%
%------------------------------------------------------------------------
% Problem geometry and grid spacing.
%------------------------------------------------------------------------
Lz                    = .4;                        % Length of comp. region in z-dir.
Ml                    = .2;                        % Length of dispersive medium.
Nz                    = 160;                       % Num. grid pts z-dir. (Need Lz/Nz int.)
Nx                    = 40;                        % Num. grid pts x-dir. (Lx=Nx*(Lz/Nz))
ddx                   = Lz/Nz;                     % Grid spacing.
dt                    = ddx/2;                     % Scaled time step.
if dt > ddx/2
  disp(' Time step does not satisy CFL condition. ')
  return
end 
params.alpha          = dt/ddx;
dt                    = dt/3e8;                    
params.dt             = dt;

%------------------------------------------------------------------------
% PML parameters.
%------------------------------------------------------------------------
npml_x                = 40;                         % Num. pml grid pts. x-dir.
npml_z                = 40;                         % Num. pml grid pts. x-dir.
pml_vec               = [1 1 0 1];                 % [X+ X- Z+ Z-]; where PMLs.

% Update Nx and Nz to account for PMLs and store.
Nx                    = Nx + (pml_vec(1) + pml_vec(2))*npml_x;
Nz                    = Nz + (pml_vec(3) + pml_vec(4))*npml_z;

[g_pmls,f_pmls] = get_pml(Nx,Nz,npml_x,npml_z,pml_vec);

%------------------------------------------------------------------------
% Input antenna and pulse parameters.
%------------------------------------------------------------------------
Az                      = 20;                           % z-coord of antenna is Az*ddx.
pulse_params.Az         = npml_z + (Az - 1);            % Account for pml.
pulse_params.Aw         = 40;                           % Antenna width. (divisible by 2)
pulse_params.Ac         = Nx/2;                         % Center of antenna.

choice                  = 2;     % 1 for Gaussian; 2 for sine wave.
pulse_params.choice     = choice;
pulse_params.amplitude  = 100;
pulse_params.pulse_type = 0;     % 1 for additive pulse; 0 for hard pulse.
if choice == 1                   % Gaussian pulse.
  pulse_params.t0 = 20;          % Center of incident pulse.
  pulse_params.stdev = 6;        % Std. deviation of gaussain pulse.
  % Cutoff pulse when the pulse value is less than its T=1 value.
  cut_off               = 2*pulse_params.t0; % Truncation threshold
  pulse_params.cut_off  = cut_off;
else                             % Sine wave pulse
  freq_in_GHz = 3;            % Frequency in gigahertz
  pulse_params.freq_in = 1e9*freq_in_GHz;           
  cut_off = 2; %input('Enter number of sine wave cycles: ');
  cut_off = cut_off/(pulse_params.freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
  pulse_params.cut_off = ceil(cut_off);
end

%------------------------------------------------------------------------
% Store necessary information 
%------------------------------------------------------------------------
params.Nx                = Nx;
params.Nz                = Nz;

params.Mstart            = ceil((Lz-Ml)/ddx)+npml_z;  % z interface of medium.
params.dt                = dt;
NSTEPS                   = 2000;                 % # time steps: forward computation.
params.NSTEPS            = NSTEPS;
params.NINNER            = 10;                 % # time steps: fortran execution.
params.output            = 1;                   % 1 at each outer iteration; 0 otherwise.
cost_params.params       = params;
cost_params.g_pmls       = g_pmls;                    % PML info.
cost_params.f_pmls       = f_pmls;                    % PML info.
cost_params.pulse_params = pulse_params;              % Pulse info.
cost_params.opt_vars     = [1 1 1 1];                 % Variable to optimize.
cost_params.a            = 1;                         % Left cutoff of E_readings.
cost_params.b            = NSTEPS;                    % Right cutoff of E_readings. 

%---------------------------------------------------------------------------
%  True parameter values for Debye medium. 
%---------------------------------------------------------------------------
x_true                   = zeros(4,1);
x_true(1)                = 1e-5;                 % Conductivity sigma.
x_true(2)                = 1/(8.1e-12*3e8);      % 1/(tau*c_0). 
x_true(3)                = 80.1;                 % epsilon_s = static permittivity.
x_true(4)                = 5.5;                  % epsilon_infty = high freq. permittivity

%---------------------------------------------------------------------------
%  Generate the data.
%---------------------------------------------------------------------------
%load E_160_40
%E_true = E_160_40(2:2:500);
%load E_320_80
%E_true = E_320_80(2:2:900);
E_true = E_function(x_true,cost_params);

prcnt_noise = input(' Input the percent noise: ');
stdev = (norm(E_true)*prcnt_noise)/(sqrt(NSTEPS)*100);
cost_params.E_true       = E_true;
cost_params.data         = E_true + stdev*randn(NSTEPS,1);
