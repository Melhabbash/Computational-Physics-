  function[E_readings] = TMsolver_mex(params,f_pmls,g_pmls,medium_params,pulse_params)
%
% This file serves as a setup for the mex interface to TMcode.f
%

%------------------------------------------------------------------------
% Extract necessary parameters.
%------------------------------------------------------------------------
Nx     = params.Nx;
Nz     = params.Nz;
dt     = params.dt;  
alpha  = params.alpha;
NSTEPS = params.NSTEPS;
output = params.output;
Mstart = params.Mstart;

% Get necessary PML parameters and vectors and update Nx and Nz.
fi2    = f_pmls.fi2;
fj2    = f_pmls.fj2;
fi3    = f_pmls.fi3;
fj3    = f_pmls.fj3;
gi1    = g_pmls.gi1;
gj1    = g_pmls.gj1;
gi2    = g_pmls.gi2;
gj2    = g_pmls.gj2;
gi3    = g_pmls.gi3;
gj3    = g_pmls.gj3;

% Get necessary medium parameters and vectors.
gb     = medium_params.gb;
gbc    = medium_params.gbc;
ga     = medium_params.ga;
const  = medium_params.const;

% Get electric pulse information.
p_choice       = pulse_params.choice;
p_cut_off      = pulse_params.cut_off;
p_type         = pulse_params.pulse_type;
amp            = pulse_params.amplitude;
Az             = pulse_params.Az + 1;
Aw             = pulse_params.Aw;
Ac             = pulse_params.Ac;
if p_choice == 1
  t0         = pulse_params.t0;
  stdev      = pulse_params.stdev;
  freq_in    = 0;
else
  freq_in    = pulse_params.freq_in;
  t0         = 0;
  stdev      = 0;
end

%------------------------------------------------------------------------
% Initialization vectors and parameters for the FDTD algorithm.
%------------------------------------------------------------------------
hx         = zeros(Nx,Nz);               % Magnetic field vector H_x.
hz         = zeros(Nx,Nz);               % Magnetic field vector H_z.
hx_hat     = zeros(Nx,Nz);               % Storage vector.     
hz_hat     = zeros(Nx,Nz);               % Storage vector.
dy         = zeros(Nx,Nz);               % Electric flux vector D_x.
dy_hat     = zeros(Nx,Nz);               % Storage vector.
ey         = zeros(Nx,Nz);               % Electric field vector Ey.
py         = zeros(Nx,Nz);               % Medium vector.
iy         = zeros(Nx,Nz);               % Storage vector.
E_readings = zeros(NSTEPS,1);           % E field storage vector.

%------------------------------------------------------------------------
% Solve the forward problem.
%------------------------------------------------------------------------

Ninner = params.NINNER;                             % Number of inner (fortran) iterations.
Nouter = NSTEPS/Ninner;

for i = 1:Nouter

  [hx,hx_hat,hz,hz_hat,dy,dy_hat,ey,py,iy,E_readings] = ...
                 fTMsolver(Nx, Nz, dt, Ninner, fi2, fj2, fi3, fj3, gi1, ... 
                           gj1, gi2, gj2, gi3, gj3, gb, gbc, ga, const, ...
                           p_choice, p_cut_off, p_type, amp, ...
                           t0, stdev, freq_in, hx, hx_hat, hz, hz_hat, dy,... 
                           dy_hat, ey, py, iy, E_readings, Az, Aw, Ac,...
                           (i-1)*Ninner, NSTEPS, alpha, Mstart);

  fprintf('iter=%d\',i*Ninner);

  %----------------------------------------------------------------------
  % Output information.
  %----------------------------------------------------------------------
  if output == 1 
    figure(1)
     subplot(211)
      %mesh(ey)
      imagesc(ey); hold on
      text(Nx/6,3*Nz/4,.5,['t = ' num2str(i*Ninner)],'fontsize',18),
      hold off;
      pause(0.1)
%     subplot(212)
%       plot(ey(Nx/2,:))
    figure(2)
      plot(ey(Nx/2,:))
%    figure(3)
%      plot(fftshift(real(fft2(ey)))) %
  end

end

