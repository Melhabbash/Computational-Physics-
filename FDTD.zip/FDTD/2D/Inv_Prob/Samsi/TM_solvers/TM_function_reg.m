  function[ J , gradJ, A ] = TM_function(x,cost_params)

%----------------------------------------------------------------------------
% Extract debye parameters from x.
%----------------------------------------------------------------------------
sigma         = x(1);                % x(1) = conductivity
tau_0         = 1/(3e8*x(2));        % x(2) = 1/tau_0*c_0
epsilon_r     = x(4);                % x(4) = epsilon_infty
chi_1         = x(3) - x(4);         % x(3) = epsilon_s

%----------------------------------------------------------------------------
% Extract necessary parameters and vectors from cost_params.
%----------------------------------------------------------------------------
params        = cost_params.params;
Nx            = params.Nx;
Nz            = params.Nz;
NSTEPS        = params.NSTEPS;
Mstart        = params.Mstart;
dt            = params.dt;
f_pmls        = cost_params.f_pmls;
g_pmls        = cost_params.g_pmls;
pulse_params  = cost_params.pulse_params;
opt_vars      = cost_params.opt_vars;
data          = cost_params.data;
cost_fn       = cost_params.cost_fn;
h             = cost_params.h;

%----------------------------------------------------------------------------
% Create necessary parameter vectors.
%----------------------------------------------------------------------------
epsilon_r_vec              = ones(Nx,Nz);    % Permittivity vector.
sigma_vec                  = zeros(Nx,Nz);   % Conductivity vector.
gbc                        = zeros(Nx,Nz);   

epsilon_r_vec(:,Mstart:Nz) = epsilon_r;            
sigma_vec(:,Mstart:Nz)     = sigma;                    
epsilon_0                  = 8.8e-12;                   % Permittivity of free space.
gb                         = (dt*sigma_vec)./epsilon_0; 
gbc(:,Mstart:Nz)           = (chi_1*dt/tau_0)/(1+.5*dt/tau_0);
ga                         = 1./(epsilon_r_vec + gb + gbc);              
const                      = (1-.5*dt/tau_0)/(1+.5*dt/tau_0);

% Ensure that at the PML boundaries Ey = 0 
% by setting appropriate ga values to 0.
ga(1,:) = 0; ga(Nx,:) = 0;  ga(:,1) = 0; ga(:,Nz) = 0;

%----------------------------------------------------------------------------
% Store the necessary vectors and parameters.
%----------------------------------------------------------------------------
medium_params.ga    = ga;
medium_params.gb    = gb;
medium_params.gbc   = gbc;
medium_params.const = const;

%----------------------------------------------------------------------------
% Evaluate the function J by first computing a forward solution.
%----------------------------------------------------------------------------

E_readings = TMsolver_mex(params,f_pmls,g_pmls,medium_params,pulse_params);
resid_vec = E_readings - data;
a       = cost_params.a;
b       = cost_params.b;
resid_vec = resid_vec(a:b,:);
J = .5*(sum(resid_vec.^2)+beta*norm(E_readings(a:b));

%----------------------------------------------------------------------------
% Gradient evaluation using finite differences.
%---------------------------------------------------------------------------- 
if nargout == 2
  % Compute the finite difference approximation to the gradient.
  n = max(size(x));
  gradJ = zeros(n,1);
  for i = 1:n
    x_h = x;
    if opt_vars(i) == 1
      x_h(i) = x(i) + h;  
      J_h = feval(cost_fn,x_h,cost_params);
      gradJ(i) = (J_h - J)/h;
     end
  end

else
  % Compute the gradient by first computing the Jacobian.
  n = max(size(x));
  Jcbn = zeros(b-a+1,n); 
  for i = 1:n
    x_h = x;
    if opt_vars(i) == 1
      x_h(i) = x(i) + h;  
      E_h = E_function(x_h,cost_params);
      Jcbn(:,i) = (E_h(a:b,:) - E_readings(a:b,:))/h;
     end  
  end
  gradJ = Jcbn'*resid_vec + beta*E_readings(a:b);
  JtJ = Jcbn'*Jcbn;
  A = JtJ + beta*eye(size(JtJ));

end  
