% Test_J.m
%
% The purpose of this m file is to get an idea of what the 
% cost function J looks like
%
%          J(q) = sum_i{(E(t_i,x*,q)-E(t_i,x*,q*))^2}.
%
% where q = (sigma,lambda,epsilon_s,epsilon_infty).

% For epsilon_infty first.

x = x_true;

z = [75:.1:85];
n = length(z);
J_vec = zeros(n,1);

for i = 1:n
  x(3) = z(i);
  J_vec(i) = TM_function(x,cost_params);

fprintf('i=%d\n',i)

figure(5)
  plot(J_vec)

end

figure(5)
  plot(J_vec)
