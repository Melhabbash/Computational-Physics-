% movie1.m

load EM_movie

figure(1)
subplot(211)

movie(M,3,2)
