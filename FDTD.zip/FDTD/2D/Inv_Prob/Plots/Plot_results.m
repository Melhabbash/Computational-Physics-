% Plot_results.m
%
% Plot the results from the optimization algorithm.

% Display results.

figure(1)

 subplot(221)
  plot(E)
  hold on
  plot(E_true,'r--')
  title('E_{true} (-), E (--)')   
  hold off

 subplot(224)
  plot(E_data)
  hold on
  plot(E_true(sample_rate:sample_rate:NSTEPS),'r--')
  title('E_{true} (-), E (--) with sampling.')   
  hold off

fprintf('TRUE:          sigma=%3.3e tau=%3.3e eps_s=%3.3e eps_infty=%3.3e\n',x_true(1),1/(3e8*x_true(2)),x_true(3),x_true(4));
fprintf('RECONSTRUCTED: sigma=%3.3e tau=%3.3e eps_s=%3.3e eps_infty=%3.3e\n',x(1),1/(3e8*x(2)),x(3),x(4));
