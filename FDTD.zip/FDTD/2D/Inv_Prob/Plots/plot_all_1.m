% Plot the respective solutions at the .05nanoseconds sampling rate.

figure(1)
choice = input(' Enter 1 to plot with sampling; 0 otherwise: ');
p2560 = input(' Enter 1 to plot E_2560_640; 0 otherwise: ');
p1280 = input(' Enter 1 to plot E_1280_320; 0 otherwise: ');
p640  = input(' Enter 1 to plot E_640_160; 0 otherwise: ');
p320  = input(' Enter 1 to plot E_320_80; 0 otherwise: ');
p160  = input(' Enter 1 to plot E_160_40; 0 otherwise: ');
p80  = input(' Enter 1 to plot E_80_20; 0 otherwise: ');

if p2560 == 1 
  load E_2560_640
  if choice == 1
    k = 192; 
  elseif p80 == 1
    k = 32;
  elseif p160 == 1 
    k = 16;
  elseif p320 == 1
    k = 8;
  elseif p640 == 1
    k = 4;
  elseif p1280 == 1
    k = 2;
  else
    k = 1;
  end
  plot(E_2560_640(k:k:7200),'m'), hold on
end
if p1280 == 1 
  load E_1280_320
  if choice == 1
    k = 96; 
  elseif p80 == 1
    k = 16;
  elseif p160 == 1 
    k = 8;
  elseif p320 == 1
    k = 4;
  elseif p640 == 1
    k = 2;
  else
    k = 1;
  end
  plot(E_1280_320(k:k:3600),'b'), hold on
end
if p640 == 1
  load E_640_160
  if choice == 1
    k = 48; 
  elseif p80 == 1
    k = 8;
  elseif p160 == 1 
    k = 4;
  elseif p320 == 1
    k = 2;
  else
    k = 1;
  end
  plot(E_640_160(k:k:1800),'r'), hold on
end
if p320 == 1
  load E_320_80
  if choice == 1
    k = 24; 
  elseif p80 == 1
    k = 4;
  elseif p160 == 1 
    k = 2;
  elseif p160 == 1
    k = 1;
  end
  plot(E_320_80(k:k:900),'g'), hold on
end
if p160 == 1
  load E_160_40  
  if choice == 1
    k = 12; 
  elseif p80 == 1
    k = 2;
  else
    k = 1;
  end
  plot(E_160_40(k:k:450),'c'), hold on
end
if p80 == 1
  load E_80_20
  if choice == 1
    k = 6; 
  else
    k = 1;
  end
  plot(E_80_20(k:k:225),'k'), hold on
end

hold off
