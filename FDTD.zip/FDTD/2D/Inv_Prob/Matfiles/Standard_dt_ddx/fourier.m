%  fourier.m
%
%  This m-file constitutes an attempt at determining the frequency 
%  content of our data.
%
%  Let x be the data vector.

N = max(size(x));
v = zeros(size(x));
imath = sqrt(-1);
dt = .4/(640*6e8);%input('dt = ');

step = 5e7;
min_step = .3e9;
max_step = 30e9;
X = zeros((max_step-min_step)/step+1,1);

for freq = min_step:step:max_step

  for T = 1:N
    v(T) = exp(-imath*2*pi*freq*dt*T);
  end

  temp = x.*v;
  X((freq-min_step)/step+1) = sum(temp);

end

X_imag = imag(X);
X_real = real(X);
vv = sqrt(X_imag.^2 + X_real.^2);

ll = [min_step/1e9:step/1e9:max_step/1e9]';
figure(1)
  plot(ll,vv)
  xlabel('GHz')
