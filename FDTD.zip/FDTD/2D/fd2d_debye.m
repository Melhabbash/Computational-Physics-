%  fd2d_TE_1.m
%
%  This is the code for Chapter 3.
%
%  This is a 2D EM simulation.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see the text.

%------------------------------------------------------------------------
% Initialization.
%------------------------------------------------------------------------
KE = 140;                        % Number of grid points.
ex = zeros(KE,KE);               % Electric field vector E_x.
ez = zeros(KE,KE);               % Electric field vector E_z.
dx = zeros(KE,KE);               % Electric flux vector D_x.
dz = zeros(KE,KE);               % Electric flux vector D_z.
hy = zeros(KE,KE);               % Magnetic field vector.
sx = zeros(KE,KE);               % Medium vector.
sz = zeros(KE,KE);               % Medium vector.
ix = zeros(KE,KE);               % Parameter vector.
iz = zeros(KE,KE);               % Parameter vector.
kc = KE/2;                       % Center of computational domain.

% PML vectors.
fi1 = zeros(KE,1);
fi2 = ones(KE,1);
fi3 = ones(KE,1);
gi2 = ones(KE,1);
gi3 = ones(KE,1);

ihx = zeros(KE,KE);
ihy = zeros(KE,KE);

%------------------------------------------------------------------------
% Determine PML parameters.
%------------------------------------------------------------------------
npml = 8;% input('Enter the number of PML cells: ');
for i= 0:npml
  xnum = npml - i;
  % D_z
  xxn = xnum/npml;
  xn = .333*xxn^3;
  gi2(i+1) = 1/(1+xn); 
  gi2(KE-i) = 1/(1+xn); gj2 = gi2;
  gi3(i+1) = (1-xn)/(1+xn);
  gi3(KE-i) = (1-xn)/(1+xn); gj3 = gi3;
  % for H_x and H_y
  xxn = (xnum - .5)/npml;
  xn = .333*xxn^3;
  fi1(i+1) = xn;
  fi1(KE-i) = xn; fj1 = fi1;
  fi2(i+1) = 1/(1+xn);
  fi2(KE-i) = 1/(1+xn); fj2 = fi2;
  fi3(i+1) = (1-xn)/(1+xn);
  fi3(KE-i) = (1-xn)/(1+xn); fj3 = fi3;
end

%------------------------------------------------------------------------
% Input dielectric constant vector and location of dielectric. 
%------------------------------------------------------------------------
epsilon_0 = 8.8e-12;             % Permittivity of free space.
epsilon_r = 2; %input('Enter the permittivity epsilon_r = '); 
epsilon_r_vec = ones(KE,KE);
dstart = input('Enter the z-coord of dielectric interface: ');
epsilon_r_vec(:,dstart:KE) = epsilon_r*epsilon_r_vec(:,dstart:KE);

%------------------------------------------------------------------------
% Input the conductivity. Ohmic conductivity: J = sigma*E.
%------------------------------------------------------------------------
sigma = .01; %input('Enter the conductivity sigma = ');
sigma_vec = zeros(KE,KE);
sigma_vec(:,dstart:KE) = sigma_vec(:,dstart:KE) + sigma;
back_bound = input('Enter 1 for metal back boundary and 0 otherwise: ');
if back_bound == 1
  sigma_vec(:,KE) = 1e6;           % To simulate a metal back boundary
end

%------------------------------------------------------------------------
% Other Debye parameters
%------------------------------------------------------------------------
chi_1 = 2; %input('Input Debye parameter Chi_1: ');
tau_0 = .001; %input('Input Debye parameter tau (in microseconds): '); 
tau_0 = 1e-6*tau_0;
model_choice = input('Enter 1 for auxilliary ODE and 0 otherwise: ');

%------------------------------------------------------------------------
% Pulse information.
%------------------------------------------------------------------------
pulse_choice = input('Enter 1 for Gaussian, 2 for sine wave pulse: ');
if pulse_choice == 1
  t0 = 20;                       % Center of incident pulse.
  stdev = 6;                    % Std. deviation of gaussain pulse.
else
  freq_in_MHz = 3000;            % Frequency in megahertz.
  freq_in = 1e6*freq_in_MHz;           
  amplitude = 1;%input('Enter the amplitude of the sine wave: ');
  cut_off = 1; %input('Enter number of sine wave cycles: ');
  cut_off = cut_off/(freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
end

% Pulse location.
la = input('Enter z-coord of antenna location: ');
da = input('Enter the width of antenna: ');
I = [la*KE + kc - da/2 : la*KE + kc + da/2];

%------------------------------------------------------------------------
% Determine step sizes ddx and dt.
%------------------------------------------------------------------------
ddx = .002; %input('Enter cell size. 1cm=.01. PROBLEM DEPENDENT! : ');
dt = ddx/6e8;                     % Calculate the time step size, Eqn. (1.7).

%------------------------------------------------------------------------
% Determine necessary vectors and constants. See (2.23)
%------------------------------------------------------------------------
gb = (dt*sigma_vec)./epsilon_0;
gbc = zeros(KE,KE);
gbc(:,dstart:KE) = gbc(:,dstart:KE) + chi_1*dt/tau_0;
ga = 1./(epsilon_r_vec + gb + gbc);
del_exp = exp(-dt/tau_0);

%------------------------------------------------------------------------
% Initialize variables.
%------------------------------------------------------------------------
T = 0;                           % Initialize time step.
show_output = 1; %input('Enter 1 for plot at each iteration; 0 otherwise: ');
NSTEPS = 500;                   % Number of time steps.

%------------------------------------------------------------------------
%------------------------------------------------------------------------
% MAIN FDTD LOOP.
%------------------------------------------------------------------------
%------------------------------------------------------------------------

for n = 1:NSTEPS

  T = T + 1;

  %----------------------------------------------------------------------
  % Determine the Hy field from Ex and Ez.
  %----------------------------------------------------------------------
  for i = 2:KE
    for j = 2:KE
      hy(i,j) = hy(i,j) + .5*(ez(i,j)-ez(i-1,j)-ex(i,j)+ex(i,j-1));
    end
  end

  %----------------------------------------------------------------------
  % Determine the Dx and Dz fields from Hy.
  %----------------------------------------------------------------------
  for i = 1:KE-1
    for j = 1:KE-1
      dx(i,j) = dx(i,j) + .5*(hy(i,j)-hy(i,j+1));
      dz(i,j) = dz(i,j) + .5*(hy(i+1,j)-hy(i,j));
    end
  end    
%------------------------------------------------------------------------
% Determine PML parameters.
%------------------------------------------------------------------------
npml = 8;% input('Enter the number of PML cells: ');
for i= 0:npml
  xnum = npml - i;
  % D_z
  xxn = xnum/npml;
  xn = .333*xxn^3;
  gi2(i+1) = 1/(1+xn); 
  gi2(KE-i) = 1/(1+xn); gj2 = gi2;
  gi3(i+1) = (1-xn)/(1+xn);
  gi3(KE-i) = (1-xn)/(1+xn); gj3 = gi3;
  % for H_x and H_y
  xxn = (xnum - .5)/npml;
  xn = .333*xxn^3;
  fi1(i+1) = xn;
  fi1(KE-i) = xn; fj1 = fi1;
  fi2(i+1) = 1/(1+xn);
  fi2(KE-i) = 1/(1+xn); fj2 = fi2;
  fi3(i+1) = (1-xn)/(1+xn);
  fi3(KE-i) = (1-xn)/(1+xn); fj3 = fi3;
end


  %----------------------------------------------------------------------
  % Generate the electric pulse.
  %----------------------------------------------------------------------
  if pulse_choice == 1
   pulse = exp(-.5*((t0-T)/stdev)^2);
  elseif T < cut_off
    pulse = amplitude*sin(2*pi*freq_in*dt*T);
  else
    pulse = 0;
  end
  dx(I) = dx(I) + pulse;  

  %----------------------------------------------------------------------
  % Determine the Ex and Ez fields from Dx and Dz.
  %----------------------------------------------------------------------
  ex = ga.*(dx - ix - sx); 
  ez = ga.*(dz - iz - sz); 
  ix = ix + gb.*ex;
  iz = iz + gb.*ez;  
  if model_choice == 1
    % Auxilliary differential equations approach.
    sx = ((1-.5*dt/tau_0)*sx + gbc.*ex)/(1+.5*dt/tau_0);
    sz = ((1-.5*dt/tau_0)*sz + gbc.*ez)/(1+.5*dt/tau_0);
  else
    % Approach outlined in 2.3.
    sx = del_exp*sx + gbc.*ex;
    sz = del_exp*sz + gbc.*ez;
  end

  %----------------------------------------------------------------------
  % Output information.
  %----------------------------------------------------------------------
  if show_output == 1
    figure(1)
      mesh(ex)
      title('E_x Field')
      xlabel('x')
      ylabel('z')
    figure(2)
      plot(ex(30,:))
      title('E_x slice')
  end

end
