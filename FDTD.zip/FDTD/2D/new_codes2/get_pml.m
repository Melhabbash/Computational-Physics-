  function[g_pmls,f_pmls] = get_pml(Nx,Nz,npml_x,npml_z,pml_vec)

%  This m-file creates the necessary PML vectors and parameters.

% Initialize PML vectors.
fi2 = ones(Nx,1);
fi3 = ones(Nx,1);
gi1 = zeros(Nx,1);
gi2 = ones(Nx,1);
gi3 = ones(Nx,1);
fj2 = ones(Nz,1);
fj3 = ones(Nz,1);
gj1 = zeros(Nz,1);
gj2 = ones(Nz,1);
gj3 = ones(Nz,1);

%------------------------------------------------------------------------
% Determine PML parameters.
%------------------------------------------------------------------------
if npml_x ~= 0
  for i= 0:npml_x
    xnum = npml_x - i;
    % D_z
    xxn = xnum/npml_x;
    xn = .333*xxn^3;
    if pml_vec(2) == 1
      gi1(i+1) = xn;
      gi2(i+1) = 1/(1+xn); 
      gi3(i+1) = (1-xn)/(1+xn);
    end
    if pml_vec(1) == 1
      gi1(Nx-i) = xn;
      gi2(Nx-i) = 1/(1+xn); 
      gi3(Nx-i) = (1-xn)/(1+xn); 
    end

    % for H_x and H_y
    xxn = (xnum - .5)/npml_x;
    xn = .333*xxn^3;
    if pml_vec(2) == 1
      fi2(i+1) = 1/(1+xn);
      fi3(i+1) = (1-xn)/(1+xn);
    end
    if pml_vec(1) == 1
      fi2(Nx-1-i) = 1/(1+xn); 
      fi3(Nx-1-i) = (1-xn)/(1+xn); 
    end
  end
end

if npml_z ~= 0
  for j = 0:npml_z
    xnum = npml_z - j;

    % D_z
    xxn = xnum/npml_z;
    xn = .333*xxn^3;
    if pml_vec(4) == 1
      gj1(j+1) = xn;
      gj2(j+1) = 1/(1+xn); 
      gj3(j+1) = (1-xn)/(1+xn);
    end
    if pml_vec(3) == 1
      gj1(Nz-j) = xn;
      gj2(Nz-j) = 1/(1+xn); 
      gj3(Nz-j) = (1-xn)/(1+xn); 
    end

    % for H_x and H_y
    xxn = (xnum - .5)/npml_z;
    xn = .333*xxn^3;
    if pml_vec(4) == 1
      fj2(j+1) = 1/(1+xn);
      fj3(j+1) = (1-xn)/(1+xn);
    end
    if pml_vec(3) == 1    
      fj2(Nz-1-j) = 1/(1+xn); 
      fj3(Nz-1-j) = (1-xn)/(1+xn); 
    end
  end
end

% Store pml vectors
f_pmls.fi2 = fi2;
f_pmls.fj2 = fj2;
f_pmls.fi3 = fi3;
f_pmls.fj3 = fj3;
g_pmls.gi1 = gi1;
g_pmls.gj1 = gj1;
g_pmls.gi2 = gi2;
g_pmls.gj2 = gj2;
g_pmls.gi3 = gi3;
g_pmls.gj3 = gj3;
