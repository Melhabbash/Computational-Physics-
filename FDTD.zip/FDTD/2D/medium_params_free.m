  function[ga,gb,gbc,medium] = medium_params_free(KE,dt);

% In this m-file we create the electric relative permittivity vector 
% epsilon_r_vec and the conductivity vector sigma_vec.

%------------------------------------------------------------------------
% Input dielectric constant vector and location of dielectric. 
%------------------------------------------------------------------------
epsilon_r_vec = ones(KE,KE);

%------------------------------------------------------------------------
% Input the conductivity. Ohmic conductivity: J = sigma*E.
%------------------------------------------------------------------------
sigma_vec = zeros(KE,KE);

%------------------------------------------------------------------------
% Determine necessary vectors and constants. See (2.23)
%------------------------------------------------------------------------
gb = zeros(KE,KE);
gbc = zeros(KE,KE);
ga = ones(KE,KE);

medium = [];
