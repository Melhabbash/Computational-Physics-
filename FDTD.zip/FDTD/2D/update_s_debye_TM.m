  function[sy] = update_s_debye_TM(sy,ey,medium)  

% This m-file updates the parameter s for a debye medium.

model_choice = medium.model_choice;
dt           = medium.dt;
tau_0        = medium.tau_0;
gbc          = medium.gbc;
del_exp      = medium.del_exp;

if model_choice == 1
  % Auxilliary differential equations approach.
  sy = ((1-.5*dt/tau_0)*sy + gbc.*ey)/(1+.5*dt/tau_0);
else
  % Approach outlined in 2.3.
  sy = del_exp*sy + gbc.*ey;
end



