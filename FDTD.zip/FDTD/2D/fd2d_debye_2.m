%  fd2d_TE_1.m
%
%  This is the code for Chapter 3.
%
%  This is a 2D EM simulation.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see the text.

cpu_t0 = cputime;

%------------------------------------------------------------------------
% Initialization.
%------------------------------------------------------------------------
KE = 140;                        % Number of grid points.
ex = zeros(KE,KE);               % Electric field vector E_x.
ez = zeros(KE,KE);               % Electric field vector E_z.
dx = zeros(KE,KE);               % Electric flux vector D_x.
dz = zeros(KE,KE);               % Electric flux vector D_z.
hy = zeros(KE,KE);               % Magnetic field vector.
hy_hat = zeros(KE,KE);           % Parameter vector.
sx = zeros(KE,KE);               % Medium vector.
sz = zeros(KE,KE);               % Medium vector.
ix = zeros(KE,KE);               % Parameter vector.
iz = zeros(KE,KE);               % Parameter vector.
kc = KE/2;                       % Center of computational domain.

% PML vectors.
fi2 = ones(KE,1);
fi3 = ones(KE,1);
gi1 = zeros(KE,1);
gi2 = ones(KE,1);
gi3 = ones(KE,1);
fj2 = ones(KE,1);
fj3 = ones(KE,1);
gj1 = zeros(KE,1);
gj2 = ones(KE,1);
gj3 = ones(KE,1);

idx = zeros(KE,KE);
idz = zeros(KE,KE);

%------------------------------------------------------------------------
% Determine PML parameters.
%------------------------------------------------------------------------
npml_x = 10;% input('Enter the number of PML cells in x-directions: ');
for i= 0:npml_x
  xnum = npml_x - i;
  % D_z
  xxn = xnum/npml_x;
  xn = .333*xxn^3;
  gi1(i+1) = xn;
  gi1(KE-i) = xn;
  gi2(i+1) = 1/(1+xn); 
  gi2(KE-i) = 1/(1+xn); 
  gi3(i+1) = (1-xn)/(1+xn);
  gi3(KE-i) = (1-xn)/(1+xn); 
  % for H_x and H_y
  xxn = (xnum - .5)/npml_x;
  xn = .333*xxn^3;
  fi2(i+1) = 1/(1+xn);
  fi2(KE-1-i) = 1/(1+xn); 
  fi3(i+1) = (1-xn)/(1+xn);
  fi3(KE-1-i) = (1-xn)/(1+xn); 
end

npml_z = 20;% input('Enter the number of PML cells in z-direction: '); 
for j = 0:npml_z
  xnum = npml_z - j;
  % D_z
  xxn = xnum/npml_z;
  xn = .333*xxn^3;
  gj1(j+1) = xn;
  %gj1(KE-j) = xn;
  gj2(j+1) = 1/(1+xn); 
  %gj2(KE-j) = 1/(1+xn); 
  gj3(j+1) = (1-xn)/(1+xn);
  %gj3(KE-j) = (1-xn)/(1+xn); 
  % for H_x and H_y
  xxn = (xnum - .5)/npml_z;
  xn = .333*xxn^3;
  fj2(j+1) = 1/(1+xn);
  %fj2(KE-1-j) = 1/(1+xn); 
  fj3(j+1) = (1-xn)/(1+xn);
  %fj3(KE-1-j) = (1-xn)/(1+xn); 
end

%------------------------------------------------------------------------
% Input dielectric constant vector and location of dielectric. 
%------------------------------------------------------------------------
epsilon_0 = 8.8e-12;             % Permittivity of free space.
epsilon_r = 2; %input('Enter the permittivity epsilon_r = '); 
epsilon_r_vec = ones(KE,KE);
dstart = input('Enter the z-coord of dielectric interface: ');
epsilon_r_vec(:,dstart:KE) = epsilon_r*epsilon_r_vec(:,dstart:KE);

%------------------------------------------------------------------------
% Input the conductivity. Ohmic conductivity: J = sigma*E.
%------------------------------------------------------------------------
sigma = .01; %input('Enter the conductivity sigma = ');
sigma_vec = zeros(KE,KE);
sigma_vec(:,dstart:KE) = sigma_vec(:,dstart:KE) + sigma;
back_bound = input('Enter 1 for metal back boundary and 0 otherwise: ');
if back_bound == 1
  sigma_vec(:,KE) = 1e6;           % To simulate a metal back boundary
end

%------------------------------------------------------------------------
% Other Debye parameters
%------------------------------------------------------------------------
chi_1 = 2; %input('Input Debye parameter Chi_1: ');
tau_0 = .001; %input('Input Debye parameter tau (in microseconds): '); 
tau_0 = 1e-6*tau_0;
model_choice = 1;% input('Enter 1 for auxilliary ODE and 0 otherwise: ');

%------------------------------------------------------------------------
% Determine step sizes ddx and dt.
%------------------------------------------------------------------------
ddx = .01; %input('Enter cell size. 1cm=.01. PROBLEM DEPENDENT! : ');
dt = ddx/6e8;                     % Calculate the time step size, Eqn. (1.7).

%------------------------------------------------------------------------
% Pulse information.
%------------------------------------------------------------------------
pulse_choice = input('Enter 1 for Gaussian, 2 for sine wave pulse: ');
if pulse_choice == 1
  t0 = 20;                       % Center of incident pulse.
  stdev = 6;                    % Std. deviation of gaussain pulse.
else
  freq_in_MHz = 1000;            % Frequency in megahertz.
  freq_in = 1e6*freq_in_MHz;           
  amplitude = 50;%input('Enter the amplitude of the sine wave: ');
  cut_off = 2; %input('Enter number of sine wave cycles: ');
  cut_off = cut_off/(freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
end

% Pulse location.
la = input('Enter z-coord of antenna location: ');
da = input('Enter the width of antenna: ');
I = [la*KE + kc - da/2 : la*KE + kc + da/2];

%------------------------------------------------------------------------
% Determine necessary vectors and constants. See (2.23)
%------------------------------------------------------------------------
gb = (dt*sigma_vec)./epsilon_0;
gbc = zeros(KE,KE);
gbc(:,dstart:KE) = gbc(:,dstart:KE) + chi_1*dt/tau_0;
ga = 1./(epsilon_r_vec + gb + gbc);
del_exp = exp(-dt/tau_0);

%------------------------------------------------------------------------
% Initialize variables.
%------------------------------------------------------------------------
T = 0;                           % Initialize time step.
show_output = 1; %input('Enter 1 for plot at each iteration; 0 otherwise: ');
NSTEPS = 500;                   % Number of time steps.

%------------------------------------------------------------------------
%------------------------------------------------------------------------
% MAIN FDTD LOOP.
%------------------------------------------------------------------------
%------------------------------------------------------------------------

for n = 1:NSTEPS

  T = T + 1;

  %----------------------------------------------------------------------
  % Determine the Hy field from Ex and Ez.
  %----------------------------------------------------------------------
  for i = 2:KE
    for j = 2:KE
      hy_hat_temp = gi3(i)*hy_hat(i,j) + gi2(i)*.5*...
                        (ez(i,j)-ez(i-1,j)-ex(i,j)+ex(i,j-1));
      hy(i,j) = gj3(j)*hy(i,j) + gj2(j)*(hy_hat_temp - hy_hat(i,j));
      hy_hat(i,j) = hy_hat_temp; 
      % This equation is what is in the book.
      %hy(i,j) = gi3(i)*gj3(j)*hy(i,j) + gi2(i)*gj2(j)*.5*...
                            (ez(i,j)-ez(i-1,j)-ex(i,j)+ex(i,j-1));
    end
  end

  %----------------------------------------------------------------------
  % Determine the Dx and Dz fields from Hy.
  %----------------------------------------------------------------------
  for i = 1:KE-1
    for j = 1:KE-1

      % Compute Dz.
      curl_h = hy(i+1,j) - hy(i,j);
      idz(i,j) = idz(i,j) + gj1(j)*curl_h;
      dz(i,j) = fi3(i)*dz(i,j) + fi2(i)*.5*curl_h + fi2(i)*idz(i,j);
      % This eqn. is in the book.
      %dz(i,j) = fi3(i)*dz(i,j) + fi2(i)*.5*(curl_h + idz(i,j));

      % Compute Dx.
      curl_h = hy(i,j) - hy(i,j+1);
      idx(i,j) = idx(i,j) + gi1(i)*curl_h;
      dx(i,j) = fj3(j)*dx(i,j) + fj2(j)*.5*curl_h + fj2(j)*idx(i,j);
      % This eqn. is in the book.
      %dx(i,j) = fj3(j)*dx(i,j) + fj2(j)*.5*(curl_h + idx(i,j));
    end
  end    

  %----------------------------------------------------------------------
  % Generate the electric pulse.
  %----------------------------------------------------------------------
  if pulse_choice == 1
    pulse = exp(-.5*((t0-T)/stdev)^2);
  elseif T < cut_off
    pulse = amplitude*sin(2*pi*freq_in*dt*T);
  else
    pulse = 0;
  end
  %dx(KE/2,la) = dx(KE/2,la) + pulse;
  dx(I) = dx(I) + pulse;

  %----------------------------------------------------------------------
  % Determine the Ex and Ez fields from Dx and Dz.
  %--------------------d--------------------------------------------------
  ex = ga.*(dx - ix - sx); 
  %ex = dx; % For free space simulation
  ez = ga.*(dz - iz - sz); 
  %ez = dz; % For free space simulation
  ix = ix + gb.*ex;
  iz = iz + gb.*ez;  

  % Set Ez edges to 0 as part of the PML.
  %ez(1,:) = 0;
  %ez(KE,:) = 0; 
  %ez(:,1) = 0;
  %ez(:,KE) = 0;

  if model_choice == 1
    % Auxilliary differential equations approach.
    sx = ((1-.5*dt/tau_0)*sx + gbc.*ex)/(1+.5*dt/tau_0);
    sz = ((1-.5*dt/tau_0)*sz + gbc.*ez)/(1+.5*dt/tau_0);
  else
    % Approach outlined in 2.3.
    sx = del_exp*sx + gbc.*ex;
    sz = del_exp*sz + gbc.*ez;
  end

  %----------------------------------------------------------------------
  % Output information.
  %----------------------------------------------------------------------
  if show_output == 1
    figure(1)
      imagesc(ex); hold on
      text(KE/4,KE/4,.5,['t = ' num2str(n)],'fontsize',18),
      hold off;
      pause(0.1)
    figure(2)
     plot(ex(KE/2,:))
  end

end

fprintf('TOTAL CPU TIME: %5.5e\n',cputime-cpu_t0);
