%  fd2d_TE_1.m
%
%  This is the code for Chapter 3.
%
%  This is a 2D EM simulation.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see the text.

%------------------------------------------------------------------------
% Initialization.
%------------------------------------------------------------------------
KE = 100;                        % Number of grid points.
ex = zeros(KE,KE);               % Electric field vector E_x.
ez = zeros(KE,KE);               % Electric field vector E_z.
dx = zeros(KE,KE);               % Electric flux vector D_x.
dz = zeros(KE,KE);               % Electric flux vector D_z.
hy = zeros(KE,KE);               % Magnetic field vector.
hy_hat = zeros(KE,KE);           % Parameter vector.
sx = zeros(KE,KE);               % Medium vector.
sz = zeros(KE,KE);               % Medium vector.
ix = zeros(KE,KE);               % Parameter vector.
iz = zeros(KE,KE);               % Parameter vector.
kc = KE/2;                % Center of computational domain.

% PML vectors.

fi2 = ones(KE,1);
fi3 = ones(KE,1);
gi1 = zeros(KE,1);
gi2 = ones(KE,1);
gi3 = ones(KE,1);
fj2 = ones(KE,1);
fj3 = ones(KE,1);
gj1 = zeros(KE,1);
gj2 = ones(KE,1);
gj3 = ones(KE,1);

iex = zeros(KE,KE);
iez = zeros(KE,KE);

%------------------------------------------------------------------------
% Determine PML parameters.
%------------------------------------------------------------------------
npml = 15;% input('Enter the number of PML cells: ');
for i= 0:npml
  xnum = npml - i;
  % D_z
  xxn = xnum/npml;
  xn = .333*xxn^3;
  gi1(i+1) = xn;
  gi1(KE-i) = xn;
  gi2(i+1) = 1/(1+xn); 
  gi2(KE-i) = 1/(1+xn); 
  gi3(i+1) = (1-xn)/(1+xn);
  gi3(KE-i) = (1-xn)/(1+xn); 
  % for H_x and H_y
  xxn = (xnum - .5)/npml;
  xn = .25*xxn^3;
  fi2(i+1) = 1/(1+xn);
  fi2(KE-1-i) = 1/(1+xn); 
  fi3(i+1) = (1-xn)/(1+xn);
  fi3(KE-1-i) = (1-xn)/(1+xn); 
end

% We leave the Z+ boundary without a PML.
gj1 = gi1; %gj1(1:npml+1) = gi1(1:npml+1);
gj2 = gi2; %gj2(1:npml+1) = gi2(1:npml+1);
gj3 = gi3; %gj3(1:npml+1) = gi3(1:npml+1);
fj2 = fi2; %fj2(1:npml+1) = fi2(1:npml+1);
fj3 = fi3; %fj3(1:npml+1) = fi3(1:npml+1);

%------------------------------------------------------------------------
% Pulse information.
%------------------------------------------------------------------------
pulse_choice = 1;%input('Enter 1 for Gaussian, 2 for sine wave pulse: ');
if pulse_choice == 1
  t0 = 20;                       % Center of incident pulse.
  stdev = 6;                    % Std. deviation of gaussain pulse.
else
  freq_in_MHz = 3000;            % Frequency in megahertz.
  freq_in = 1e6*freq_in_MHz;           
  amplitude = 1;%input('Enter the amplitude of the sine wave: ');
  cut_off = 1; %input('Enter number of sine wave cycles: ');
  cut_off = cut_off/(freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
end

%------------------------------------------------------------------------
% Determine step sizes ddx and dt.
%------------------------------------------------------------------------
disp('WARNING: REMEMBER THAT THE STEP SIZES ARE PROBLEM DEPENDENT!!!')
ddx = .01;                       % Cell size. Eqn. (1.19). Here 1cm = .01.
dt = ddx/6e8;                     % Calculate the time step size, Eqn. (1.7).

%------------------------------------------------------------------------
% Initialize variables.
%------------------------------------------------------------------------
T = 0;                           % Initialize time step.
show_output = 1; %input('Enter 1 for plot at each iteration; 0 otherwise: ');
NSTEPS = 1000;                   % Number of time steps.

%------------------------------------------------------------------------
%------------------------------------------------------------------------
% MAIN FDTD LOOP.
%------------------------------------------------------------------------
%------------------------------------------------------------------------

for n = 1:NSTEPS

  T = T + 1;

  %----------------------------------------------------------------------
  % Determine the Hy field from Ex and Ez.
  %----------------------------------------------------------------------
  for i = 2:KE
    for j = 2:KE
      %hy(i,j) = hy(i,j) + .5*(ez(i,j)-ez(i-1,j)-ex(i,j)+ex(i,j-1));
      %hy(i,j) = gi3(i)*gj3(j)*hy(i,j) + gi2(i)*gj2(j)*.5*...
                            (ez(i,j)-ez(i-1,j)-ex(i,j)+ex(i,j-1));
      hy_hat_temp = gi3(i)*hy_hat(i,j) + gi2(i)*.5*...
                        (ez(i,j)-ez(i-1,j)-ex(i,j)+ex(i,j-1));
      hy(i,j) = gj3(j)*hy(i,j) + gj2(j)*(hy_hat_temp - hy_hat(i,j));
      hy_hat(i,j) = hy_hat_temp; 
     end
  end

  %----------------------------------------------------------------------
  % Determine the Dx and Dz fields from Hy.
  %----------------------------------------------------------------------
  for i = 1:KE-1
    for j = 1:KE-1
      curl_h = hy(i+1,j) - hy(i,j);
      iez(i,j) = iez(i,j) + gj1(j)*curl_h;
      ez(i,j) = fi3(i)*ez(i,j) + fi2(i)*.5*curl_h + fi2(i)*iez(i,j);

      curl_h = hy(i,j) - hy(i,j+1);
      iex(i,j) = iex(i,j) + gi1(i)*curl_h;
      ex(i,j) = fj3(j)*ex(i,j) + fj2(j)*.5*curl_h + fj2(j)*iex(i,j);
    end
  end    

  %----------------------------------------------------------------------
  % Generate the electric pulse.
  %----------------------------------------------------------------------
  if pulse_choice == 1
   pulse = exp(-.5*((t0-T)/stdev)^2);
  elseif T < cut_off
    pulse = amplitude*sin(2*pi*freq_in*dt*T);
  else
    pulse = 0;
  end
  ex(kc-5,kc-5) = pulse;  

  % Set Ez edges to 0 as part of the PML.
  ez(1,:) = 0;
  ez(KE,:) = 0; 
  ez(:,1) = 0;
  ez(:,KE) = 0;

  %----------------------------------------------------------------------
  % Output information.
  %----------------------------------------------------------------------
  if show_output == 1
    figure(1)
      imagesc(ex); hold on
      text(KE/4,KE/4,.5,['t = ' num2str(n)],'fontsize',18),
      hold off;
      pause(0.1)
 
  end

end

