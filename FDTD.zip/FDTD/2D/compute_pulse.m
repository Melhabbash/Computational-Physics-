  function[d] = compute_pulse(d,T,params)

% Compute electromagnetic pulse.

cut_off = params.cut_off;
I = params.I;

if params.choice == 1 %& T < cut_off
  pulse = params.amplitude*exp(-.5*((params.t0-T)/params.stdev)^2);
  d(I) =  d(I) + pulse;
  %d(I) = pulse;
elseif params.choice == 2 & T < cut_off
  pulse = params.amplitude*sin(2*pi*params.freq_in*params.dt*T);
  d(I) =  d(I) + pulse;
  %d(I) = pulse;
else
  d(I) = 0;
end
