  function[sx,sz] = update_s_debye_TE(sx,sz,ex,ez,medium)  

% This m-file updates the parameter s for a debye medium.

model_choice = medium.model_choice;
dt           = medium.dt;
tau_0        = medium.tau_0;
gbc          = medium.gbc;
del_exp      = medium.del_exp;

if model_choice == 1
  % Auxilliary differential equations approach.
  sx = ((1-.5*dt/tau_0)*sx + gbc.*ex)/(1+.5*dt/tau_0);
  sz = ((1-.5*dt/tau_0)*sz + gbc.*ez)/(1+.5*dt/tau_0);
else
  % Approach outlined in 2.3.
  sx = del_exp*sx + gbc.*ex;
  sz = del_exp*sz + gbc.*ez;
end



