  function[py] = update_s_debye_TM(py,ey,medium)  

% This m-file updates the parameter s for a debye medium.
% The Auxiliary differential equations approach is taken.

dt           = medium.dt;
tau_0        = medium.tau_0;
gbc          = medium.gbc;

py = ((1-.5*dt/tau_0)*py + gbc.*ey)/(1+.5*dt/tau_0);
