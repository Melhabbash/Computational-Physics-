  function[d] = compute_pulse(d,T,params)

% Compute electromagnetic pulse.

cut_off = params.cut_off;
pulse_type = params.pulse_type;
I = params.I;

if params.choice == 1 & T < cut_off
  pulse = params.amplitude*exp(-.5*((params.t0-T)/params.stdev)^2);
  if pulse_type == 1
    d(I) =  d(I) + pulse;
  else
    d(I) = pulse;
  end

elseif params.choice == 2 & T < cut_off
  pulse = params.amplitude*sin(2*pi*params.freq_in*params.dt*T);
  if pulse_type == 1
    d(I) =  d(I) + pulse;
  else
    d(I) = pulse;
  end
else
  if pulse_type == 1
    d(I) = d(I);
  else
    d(I) = 0;
  end
end
