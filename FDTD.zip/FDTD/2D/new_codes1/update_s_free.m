  function[sx,sz] = update_s_free(sx,sz,ex,ez,medium)  

% This m-file updates the parameter s for a debye medium.



