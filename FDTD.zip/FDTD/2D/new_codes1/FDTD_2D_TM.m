%  FDTD_2D_TM.m
%
%  This is the code for Chapter 3.
%
%  This is a 2D EM simulation.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%------------------------------------------------------------------------
% Geometry of problem.
%------------------------------------------------------------------------
%   x-axis ^  dielectric
%          |  interface    X+           E=0 boundary
%    ______|_____|_______________________|
%   |            pml                     | 
%   |      ______________________________|
%   |      |free |                       |  
%   |      |space|      dielectric       |
%   |      |     |                       |
% Z-| pml  |    computational region     |Z+
%   |      | *   |                       |
%   |      | antenna                     |
%   |      |     |                       |  
%   |   z=0 -----|---------------------z=Lz---> z-axis
%   |           z=z0      pml            |
%   |____________________________________|
%                          X-
%------------------------------------------------------------------------

cpu_t0 = cputime;

%------------------------------------------------------------------------
% Initialize necessary parameters.
%------------------------------------------------------------------------
% Problem geometry and grid spacing.
Lz                    = .4;                        % Length of comp. region in z-dir.
Nz                    = 160;                       % Num. grid pts z-dir. (Need Lz/Nz int.)
Nx                    = 40;                        % Num. grid pts x-dir. (Lx=Nx*(Lz/Nz))
ddx                   = Lz/Nz;                     % Grid spacing.
dt                    = ddx/6e8;                   % Time step size, Eqn. (1.7).

% PML parameters.
pml.npml_x            = 8;                         % Num. pml grid pts. x-dir.
pml.npml_z            = 20;                        % Num. pml grid pts. x-dir.
% Determine bounderies on which you want pml's.
%       pml_vec(1) = 1 for pml on X+; 0 for no pml.
%       pml_vec(2) = 1 for pml on X-; 0 for no pml.
%       pml_vec(3) = 1 for pml on Z+; 0 for no pml.
%       pml_vec(4) = 1 for pml on Z-; 0 for no pml.
pml.pml_vec = [1 1 0 1];
% Increase Nx and Nz to account for PMLs.
Nx  = Nx + (pml_vec(1) + pml_vec(2))*npml_x;
Nz  = Nz + (pml_vec(3) + pml_vec(4))*npml_z;

% Medium parameters.
Ml     = .3;                                          % Length of dispersive medium.
medium.Mstart         = ceil((Lz - Ml)/ddx) + npml_z; % z interface of medium.
medium.epsilon_r      = 5;                            % Relative permittivity.
medium.chi_1          = 30;                           % Debye ODE parameter.
medium.tau_0          = 1e-11;                        % Debye ODE parameter.
medium.sigma          = .01;                          % Conductivity.
medium.back_bound     = 0;                            % 1 -> sigma = 1e6; 0 -> E=0.

% Antenna and pulse parameters.
Az                    = 10;                           % z-coord of antenna is Az*ddx.
pulse.Az              = npml_z + (Az - 1);            % Account for pml.
pulse.Aw              = 8;                            % Antenna width. (divisible by 2)
pulse.Ac              = Nx/2;                         % Center of antenna.
pulse.choice          = 2;                            % 1 for Gaussian; 2 for sine wave.

%------------------------------------------------------------------------
% Get necessary PML parameters and vectors and update Nx and Nz.
%------------------------------------------------------------------------
[gi1,gi2,gi3,gj1,gj2,gj3,fi2,fi3,fj2,fj3] = get_pml(Nz,Nx,pml);

%------------------------------------------------------------------------
% Get necessary medium parameters and vectors.
%------------------------------------------------------------------------
[ga,gb,gbc,medium] = medium_params_debye(Nx,Nz,dt,medium);

%------------------------------------------------------------------------
% Get electric pulse information.
%------------------------------------------------------------------------
[pulse] = get_pulse(Nx,dt,pulse);

%------------------------------------------------------------------------
% Initialization vectors and parameters for the FDTD algorithm.
%------------------------------------------------------------------------
hx     = zeros(Nx,Nz);               % Magnetic field vector H_x.
hz     = zeros(Nx,Nz);               % Magnetic field vector H_z.
ihx    = zeros(Nx,Nz);               % Storage vector.     
ihz    = zeros(Nx,Nz);               % Storage vector.
dy     = zeros(Nx,Nz);               % Electric flux vector D_x.
dy_hat = zeros(Nx,Nz);               % Storage vector.
ey     = zeros(Nx,Nz);               % Electric field vector Ey.
sy     = zeros(Nx,Nz);               % Medium vector.
iy     = zeros(Nx,Nz);               % Storage vector.

show_output = 1; %input('Enter 1 for plot at each iteration; 0 otherwise: ');

%------------------------------------------------------------------------
%------------------------------------------------------------------------
% MAIN FDTD LOOP.
%------------------------------------------------------------------------
%------------------------------------------------------------------------

T = 0;                              % Initialize time step.
NSTEPS = 1000;                      % Number of time steps.

for n = 1:NSTEPS

  T = T + 1;

  %----------------------------------------------------------------------
  % Determine the Dy field from Hx and Hz.
  %----------------------------------------------------------------------
  for i = 2:Nx
    for j = 2:Nz
      dy_hat_temp = gi3(i)*dy_hat(i,j) + gi2(i)*.5*...
                        (hz(i,j)-hz(i-1,j)-hx(i,j)+hx(i,j-1));
      dy(i,j) = gj3(j)*dy(i,j) + gj2(j)*(dy_hat_temp - dy_hat(i,j));
      dy_hat(i,j) = dy_hat_temp; 
    end
  end

  %----------------------------------------------------------------------
  % Generate the electric pulse.
  %----------------------------------------------------------------------
  dy = compute_pulse(dy,T,pulse);  

  %----------------------------------------------------------------------
  % Determine the Ey field from Dy. Update Iy and Sy.
  %--------------------d--------------------------------------------------
  ey = ga.*(dy - iy - sy); 

  % Set Ez edges to 0 as part of the PML. This is done in the book.
  ey(1,:) = 0; ey(Nx,:) = 0; ey(:,1) = 0; ey(:,Nz) = 0;

  iy = iy + gb.*ey;

  sy = update_s_debye_TM(sy,ey,medium);

  %----------------------------------------------------------------------
  % Determine the Hx and Hz fields from Ey.
  %----------------------------------------------------------------------
  for i = 1:Nx-1
    for j = 1:Nz-1

      % Compute Hz.
      curl_e = ey(i+1,j) - ey(i,j);
      ihz(i,j) = ihz(i,j) + gj1(j)*curl_e;  % Necessary for PMLs.   
      hz(i,j) = fi3(i)*hz(i,j) + fi2(i)*.5*curl_e + fi2(i)*ihz(i,j);

      % Compute Hx.
      curl_e = ey(i,j) - ey(i,j+1);
      ihx(i,j) = ihx(i,j) + gi1(i)*curl_e;  % Necessary for PMLs.
      hx(i,j) = fj3(j)*hx(i,j) + fj2(j)*.5*curl_e + fj2(j)*ihx(i,j);
    end
  end    

  %----------------------------------------------------------------------
  % Output information.
  %----------------------------------------------------------------------
  if show_output == 1 %%& ceil(T/10) == T/10
    figure(1)
     subplot(211)
      imagesc(ey); hold on
      text(Nx/6,3*Nz/4,.5,['t = ' num2str(n)],'fontsize',18),
      hold off;
      pause(0.1)
     subplot(212)
      plot(ey(Nx/2,:))
%    figure(2)
%     subplot(211)
%       plot(ey(Nx/2,:))
%     subplot(212)
%       plot(ey(Nx/2,Mstart:Nz))
  end

end

fprintf('TOTAL CPU TIME: %5.5e\n',cputime-cpu_t0);

