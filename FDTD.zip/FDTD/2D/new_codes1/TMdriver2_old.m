%  TMdriver.m
%
%  This is a 2D EM simulation using the FDTD method.
%  For a reference, see Chapters 2 and 3 in
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%------------------------------------------------------------------------
% Geometry of problem.
%------------------------------------------------------------------------
%   x-axis ^  dielectric
%          |  interface    X+           Exn=0 boundary
%    ______|_____|_______________________|
%   |            pml                     | 
%   |      ______________________________|
%   |      |free |                       |  
%   |      |space|      dielectric       |
%   |      |     |                       |
% Z-| pml  |    computational region     |Z+
%   |      | *   |                       |
%   |      | antenna                     |
%   |      |     |                       |  
%   |   z=0 -----|---------------------z=Lz---> z-axis
%   |           z=z0      pml            |
%   |____________________________________|
%                          X-
%------------------------------------------------------------------------

cpu_t0 = cputime;

%------------------------------------------------------------------------
% Problem geometry and grid spacing.
%------------------------------------------------------------------------
Lz                    = .16;                       % Length of comp. region in z-dir.
Nz                    = 80;                        % Num. grid pts z-dir. (Need Lz/Nz int.)
Nx                    = 40;                        % Num. grid pts x-dir. (Lx=Nx*(Lz/Nz))
ddx                   = Lz/Nz;                     % Grid spacing.
dt                    = ddx/6e8;                   % Time step size, Eqn. (1.7).
params.dt             = dt;
params.NSTEPS         = 1000;                      % Number of time steps.

% Output information.
params.output    = 1;                              % 1 at each iteration; 0 otherwise.

%------------------------------------------------------------------------
% PML parameters.
%------------------------------------------------------------------------
npml_x                = 8;                         % Num. pml grid pts. x-dir.
npml_z                = 8;                         % Num. pml grid pts. x-dir.
pml_vec               = [1 1 0 1];                 % [X+ X- Z+ Z-]; where PMLs.

% Update Nx and Nz to account for PMLs and store.
Nx                    = Nx + (pml_vec(1) + pml_vec(2))*npml_x;
Nz                    = Nz + (pml_vec(3) + pml_vec(4))*npml_z;
params.Nx             = Nx;
params.Nz             = Nz;

[g_pmls,f_pmls] = get_pml2(Nx,Nz,npml_x,npml_z,pml_vec);

%------------------------------------------------------------------------
% Input medium parameters and get necessary parameters.
%------------------------------------------------------------------------
Ml                    = .1;                           % Length of dispersive medium.
Mstart                = ceil((Lz-Ml)/ddx)+npml_z;     % z interface of medium.
epsilon_r             = 5;                            % Relative permittivity.
sigma                 = .01;                          % Conductivity.
chi_1                 = 30;                           % Debye ODE parameter.
tau_0                 = 1e-11;                        % Debye ODE parameter.

% Create dielectric constant vector and determine dielectric geometry. 
epsilon_r_vec = ones(Nx,Nz);                          
epsilon_r_vec(:,Mstart:Nz) = epsilon_r;

% Create conductivity vector given above geometry (J = sigma*E.).
sigma_vec = zeros(Nx,Nz);
sigma_vec(:,Mstart:Nz) = sigma;

% Determine necessary vectors and constants. See (2.23 Sullivan)
epsilon_0 = 8.8e-12;             % Permittivity of free space.
gb = (dt*sigma_vec)./epsilon_0;
gbc = zeros(Nx,Nz);
gbc(:,Mstart:Nz) = chi_1*dt/tau_0;
ga = 1./(epsilon_r_vec + gb + gbc);

% Store the necessary vectors and parameters.
medium_params.ga    = ga;
medium_params.gb    = gb;
medium_params.gbc   = gbc;
medium_params.tau_0 = tau_0;

%------------------------------------------------------------------------
% Input antenna and pulse parameters.
%------------------------------------------------------------------------
Az                      = 5;                            % z-coord of antenna is Az*ddx.
Az                      = npml_z + (Az - 1);            % Account for pml.
Aw                      = 8;                            % Antenna width. (divisible by 2)
Ac                      = Nx/2;                         % Center of antenna.
pulse_params.I          = [ Nx*Az + Ac - Aw/2 : Nx*Az + Ac + Aw/2];

choice                  = 1;     % 1 for Gaussian; 2 for sine wave.
pulse_params.choice     = choice;
pulse_params.amplitude  = 1;     % Pulse amplitude.
pulse_params.pulse_type = 1;     % 1 for additive pulse; 0 for hard pulse.
if choice == 1                   % Gaussian pulse.
  pulse_params.t0 = 20;          % Center of incident pulse.
  pulse_params.stdev = 6;        % Std. deviation of gaussain pulse.
  % Cutoff pulse when the pulse value is less than its T=1 value.
  pulse_params.cut_off = 2*pulse_params.t0; % Truncation threshold

else                             % Sine wave pulse
  freq_in_MHz = 3000;            % Frequency in megahertz.
  pulse_params.freq_in = 1e6*freq_in_MHz;           
  cut_off = 3; %input('Enter number of sine wave cycles: ');
  pulse_params.cut_off = cut_off/(pulse.freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
end

%------------------------------------------------------------------------
% Compute a forward solution.
%------------------------------------------------------------------------

[E_readings] = TMsolver2_old(params,f_pmls,g_pmls,medium_params,pulse_params);

fprintf('TOTAL CPU TIME: %5.5e\n',cputime-cpu_t0);








