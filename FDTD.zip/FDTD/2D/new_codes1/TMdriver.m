%  TMdriver.m
%
%  This is a 2D EM simulation using the FDTD method.
%  For a reference, see Chapters 2 and 3 in
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%------------------------------------------------------------------------
% Geometry of problem.
%------------------------------------------------------------------------
%   x-axis ^  dielectric
%          |  interface    X+           Exn=0 boundary
%    ______|_____|_______________________|
%   |            pml                     | 
%   |      ______________________________|
%   |      |free |                       |  
%   |      |space|      dielectric       |
%   |      |     |                       |
% Z-| pml  |    computational region     |Z+
%   |      | *   |                       |
%   |      | antenna                     |
%   |      |     |                       |  
%   |   z=0 -----|---------------------z=Lz---> z-axis
%   |           z=z0      pml            |
%   |____________________________________|
%                          X-
%------------------------------------------------------------------------

cpu_t0 = cputime;

%------------------------------------------------------------------------
% Initialize necessary parameters.
%------------------------------------------------------------------------
% Problem geometry and grid spacing.
Lz                    = .16;                        % Length of comp. region in z-dir.
Nz                    = 80;                       % Num. grid pts z-dir. (Need Lz/Nz int.)
Nx                    = 40;                        % Num. grid pts x-dir. (Lx=Nx*(Lz/Nz))
ddx                   = Lz/Nz;                     % Grid spacing.
params.dt             = ddx/6e8;                   % Time step size, Eqn. (1.7).
params.NSTEPS         = 1000;                      % Number of time steps.

% PML parameters.
pml.npml_x            = 8;                         % Num. pml grid pts. x-dir.
pml.npml_z            = 8;                        % Num. pml grid pts. x-dir.
pml.pml_vec = [1 1 0 1];

% Increase Nx and Nz to account for PMLs.
params.Nx             = Nx + (pml_vec(1) + pml_vec(2))*pml.npml_x;
params.Nz             = Nz + (pml_vec(3) + pml_vec(4))*pml.npml_z;

% Medium parameters.
Ml                    = .1;                           % Length of dispersive medium.
medium.Mstart         = ceil((Lz-Ml)/ddx)+pml.npml_z; % z interface of medium.
medium.epsilon_r      = 5;                            % Relative permittivity.
medium.chi_1          = 30;                           % Debye ODE parameter.
medium.tau_0          = 1e-11;                        % Debye ODE parameter.
medium.sigma          = .01;                          % Conductivity.
medium.back_bound     = 0;                            % 1 -> sigma = 1e6; 0 -> E=0.

% Antenna and pulse parameters.
Az                    = 5;                            % z-coord of antenna is Az*ddx.
pulse.Az              = pml.npml_z + (Az - 1);        % Account for pml.
pulse.Aw              = 8;                            % Antenna width. (divisible by 2)
pulse.Ac              = params.Nx/2;                  % Center of antenna.
pulse.choice          = 1;                            % 1 for Gaussian; 2 for sine wave.

% Output information.
params.output    = 1;                                 % 1 at each iteration; 0 o.w.

% Compute a forward solution.
[E_readings] = TMsolver(params,pml,medium,pulse);

fprintf('TOTAL CPU TIME: %5.5e\n',cputime-cpu_t0);





