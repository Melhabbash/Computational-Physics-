  function[ga,gb,gbc,medium] = medium_params_debye(Nx,Nz,dt,medium)

% In this m-file we create the parameters that characterize the medium.

%------------------------------------------------------------------------
% Necessary parameters
%------------------------------------------------------------------------
Mstart     = medium.Mstart;
chi_1      = medium.chi_1;
tau_0      = medium.tau_0;
epsilon_r  = medium.epsilon_r;
sigma      = medium.sigma;
back_bound = medium.back_bound;

%------------------------------------------------------------------------
% Input dielectric constant vector and location of dielectric. 
%------------------------------------------------------------------------
epsilon_r_vec = ones(Nx,Nz);
epsilon_r_vec(:,Mstart:Nz) = epsilon_r*epsilon_r_vec(:,Mstart:Nz);

%------------------------------------------------------------------------
% Input the conductivity. Ohmic conductivity: J = sigma*E.
%------------------------------------------------------------------------
sigma_vec = zeros(Nx,Nz);
sigma_vec(:,Mstart:Nz) = sigma_vec(:,Mstart:Nz) + sigma;
if back_bound == 1
  sigma_vec(:,Nz) = 1e6;           % To simulate a metal back boundary
end

%------------------------------------------------------------------------
% Determine necessary vectors and constants. See (2.23)
%------------------------------------------------------------------------
epsilon_0 = 8.8e-12;             % Permittivity of free space.
gb = (dt*sigma_vec)./epsilon_0;
gbc = zeros(Nx,Nz);
gbc(:,Mstart:Nz) = gbc(:,Mstart:Nz) + chi_1*dt/tau_0;
ga = 1./(epsilon_r_vec + gb + gbc);

%------------------------------------------------------------------------
% Save the parameters necessary for later calculations
%------------------------------------------------------------------------

medium.gbc          = gbc;
medium.dt           = dt;
