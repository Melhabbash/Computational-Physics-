  function[pulse] = get_pulse(Nx,dt,pulse)

%------------------------------------------------------------------------
% Get electric pulse information.
%------------------------------------------------------------------------
choice = pulse.choice;

if choice == 1
  pulse.t0 = 20;                 % Center of incident pulse.
  pulse.stdev = 6;               % Std. deviation of gaussain pulse.
  % Cutoff pulse when the pulse value is less than its T=1 value.
  pulse.cut_off = 2*pulse.t0;
else
  freq_in_MHz = 3000;            % Frequency in megahertz.
  pulse.freq_in = 1e6*freq_in_MHz;           
  cut_off = 3; %input('Enter number of sine wave cycles: ');
  pulse.cut_off = cut_off/(pulse.freq_in*dt);  
  if ceil(cut_off) ~= cut_off    % Equal if freq_in_MHZ*ddx divides 3e8.
    disp('WARNING: SINE WAVE CUTOFF NONZERO!!!')
  end
  pulse.dt = dt;
end

% Determine the type of pulse used.
pulse.amplitude = 1;             % Pulse amplitude.
pulse.pulse_type = 1;            % 1 for additive pulse; 0 for hard pulse.

% Antenna coordinates.
Az   = pulse.Az;
Aw   = pulse.Aw;
Ac   = pulse.Ac;

pulse.I = [ Nx*Az + Ac - Aw/2 : Nx*Az + Ac + Aw/2];

