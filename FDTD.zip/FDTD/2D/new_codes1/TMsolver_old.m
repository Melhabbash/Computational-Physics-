  function[E_readings] = TMsolver(params,f_pmls,g_pmls,medium_params,pulse_params)

%------------------------------------------------------------------------
% Extract necessary parameters.
%------------------------------------------------------------------------
Nx     = params.Nx;
Nz     = params.Nz;
dt     = params.dt;  
NSTEPS = params.NSTEPS;
output = params.output;

% Get necessary PML parameters and vectors and update Nx and Nz.
fi2    = f_pmls.fi2;
fj2    = f_pmls.fj2;
fi3    = f_pmls.fi3;
fj3    = f_pmls.fj3;
gi1    = g_pmls.gi1;
gj1    = g_pmls.gj1;
gi2    = g_pmls.gi2;
gj2    = g_pmls.gj2;
gi3    = g_pmls.gi3;
gj3    = g_pmls.gj3;

% Get necessary medium parameters and vectors.
tau_0  = medium_params.tau_0;
gb     = medium_params.gb;
gbc    = medium_params.gbc;
ga     = medium_params.ga;

% Get electric pulse information.
pulse_choice = pulse_params.choice;
cut_off      = pulse_params.cut_off;
pulse_type   = pulse_params.pulse_type;
I            = pulse_params.I;
amplitude    = pulse_params.amplitude;
if pulse_choice == 1
  t0         = pulse_params.t0;
  stdev      = pulse_params.stdev;
else
  freq       = pulse_params.freq_in;
end

%------------------------------------------------------------------------
% Initialization vectors and parameters for the FDTD algorithm.
%------------------------------------------------------------------------
hx         = zeros(Nx,Nz);               % Magnetic field vector H_x.
hz         = zeros(Nx,Nz);               % Magnetic field vector H_z.
ihx        = zeros(Nx,Nz);               % Storage vector.     
ihz        = zeros(Nx,Nz);               % Storage vector.
dy         = zeros(Nx,Nz);               % Electric flux vector D_x.
dy_hat     = zeros(Nx,Nz);               % Storage vector.
ey         = zeros(Nx,Nz);               % Electric field vector Ey.
py         = zeros(Nx,Nz);               % Medium vector.
iy         = zeros(Nx,Nz);               % Storage vector.
E_readings = zeros(NSTEPS,1);            % E field storage vector.

%------------------------------------------------------------------------
%------------------------------------------------------------------------
% MAIN FDTD LOOP.
%------------------------------------------------------------------------
%------------------------------------------------------------------------

T = 0;                              % Initialize time step.

for n = 1:NSTEPS

  T = T + 1;

  %----------------------------------------------------------------------
  % Determine the Dy field from Hx and Hz.
  %----------------------------------------------------------------------
  for i = 2:Nx
    for j = 2:Nz
      dy_hat_temp = gi3(i)*dy_hat(i,j) + gi2(i)*.5*...
                        (hz(i,j)-hz(i-1,j)-hx(i,j)+hx(i,j-1));
      dy(i,j) = gj3(j)*dy(i,j) + gj2(j)*(dy_hat_temp - dy_hat(i,j));
      dy_hat(i,j) = dy_hat_temp; 
    end
  end

  %----------------------------------------------------------------------
  % Generate the electric pulse.
  %----------------------------------------------------------------------
  if pulse_choice == 1 & T < cut_off
    pulse = amplitude*exp(-.5*((t0-T)/stdev)^2);
    if pulse_type == 1
      dy(I) =  dy(I) + pulse;
    else
      dy(I) = pulse;
    end

  elseif pulse_choice == 2 & T < cut_off
    pulse = amplitude*sin(2*pi*freq_in*dt*T);
    if pulse_type == 1
      dy(I) =  dy(I) + pulse;
    else
      dy(I) = pulse;
    end
  else
    if pulse_type == 1
      dy(I) = dy(I);
    else
      dy(I) = 0;
    end
  end


  %----------------------------------------------------------------------
  % Determine the Ey field from Dy. Update Iy and Py.
  %--------------------d--------------------------------------------------
  ey = ga.*(dy - iy - py); 

  % Set appropriate Ey edges to 0 as part of the PML. 
  ey(1,:) = 0; ey(Nx,:) = 0; ey(:,1) = 0; %ey(:,Nz) = 0;

  iy = iy + gb.*ey;

  py = ((1-.5*dt/tau_0)*py + gbc.*ey)/(1+.5*dt/tau_0);

  %----------------------------------------------------------------------
  % Determine the Hx and Hz fields from Ey.
  %----------------------------------------------------------------------
  for i = 1:Nx-1
    for j = 1:Nz-1

      % Compute Hz.
      curl_e = ey(i+1,j) - ey(i,j);
      ihz(i,j) = ihz(i,j) + gj1(j)*curl_e;  % Necessary for PMLs.   
      hz(i,j) = fi3(i)*hz(i,j) + fi2(i)*.5*curl_e + fi2(i)*ihz(i,j);

      % Compute Hx.
      curl_e = ey(i,j) - ey(i,j+1);
      ihx(i,j) = ihx(i,j) + gi1(i)*curl_e;  % Necessary for PMLs.
      hx(i,j) = fj3(j)*hx(i,j) + fj2(j)*.5*curl_e + fj2(j)*ihx(i,j);
    end
  end    

  %----------------------------------------------------------------------
  % Output information.
  %----------------------------------------------------------------------
  if output == 1 %%& ceil(T/10) == T/10
    figure(1)
     subplot(211)
      imagesc(ey); hold on
      text(Nx/6,3*Nz/4,.5,['t = ' num2str(n)],'fontsize',18),
      hold off;
      pause(0.1)
     subplot(212)
      plot(ey(Nx/2,:))
%    figure(2)
%     subplot(211)
%       plot(ey(Nx/2,:))
%     subplot(212)
%       plot(ey(Nx/2,Mstart:Nz))
  end

end

