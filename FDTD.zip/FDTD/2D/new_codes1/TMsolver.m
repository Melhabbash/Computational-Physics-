  function[E_readings] = TMsolver(params,pml,medium,pulse)

%------------------------------------------------------------------------
% Extract necessary parameters.
%------------------------------------------------------------------------
Nx     = params.Nx;
Nz     = params.Nz;
dt     = params.dt;  
NSTEPS = params.NSTEPS;
output = params.output;

%------------------------------------------------------------------------
% Get necessary PML parameters and vectors and update Nx and Nz.
%------------------------------------------------------------------------
[gi1,gi2,gi3,gj1,gj2,gj3,fi2,fi3,fj2,fj3] = get_pml(Nz,Nx,pml);

%------------------------------------------------------------------------
% Get necessary medium parameters and vectors.
%------------------------------------------------------------------------
[ga,gb,gbc,medium] = medium_params_debye(Nx,Nz,dt,medium);

%------------------------------------------------------------------------
% Get electric pulse information.
%------------------------------------------------------------------------
[pulse] = get_pulse(Nx,dt,pulse);

%------------------------------------------------------------------------
% Initialization vectors and parameters for the FDTD algorithm.
%------------------------------------------------------------------------
hx         = zeros(Nx,Nz);               % Magnetic field vector H_x.
hz         = zeros(Nx,Nz);               % Magnetic field vector H_z.
ihx        = zeros(Nx,Nz);               % Storage vector.     
ihz        = zeros(Nx,Nz);               % Storage vector.
dy         = zeros(Nx,Nz);               % Electric flux vector D_x.
dy_hat     = zeros(Nx,Nz);               % Storage vector.
ey         = zeros(Nx,Nz);               % Electric field vector Ey.
sy         = zeros(Nx,Nz);               % Medium vector.
iy         = zeros(Nx,Nz);               % Storage vector.
E_readings = zeros(NSTEPS,1);            % E field storage vector.

%------------------------------------------------------------------------
%------------------------------------------------------------------------
% MAIN FDTD LOOP.
%------------------------------------------------------------------------
%------------------------------------------------------------------------

T = 0;                              % Initialize time step.

for n = 1:NSTEPS

  T = T + 1;

  %----------------------------------------------------------------------
  % Determine the Dy field from Hx and Hz.
  %----------------------------------------------------------------------
  for i = 2:Nx
    for j = 2:Nz
      dy_hat_temp = gi3(i)*dy_hat(i,j) + gi2(i)*.5*...
                        (hz(i,j)-hz(i-1,j)-hx(i,j)+hx(i,j-1));
      dy(i,j) = gj3(j)*dy(i,j) + gj2(j)*(dy_hat_temp - dy_hat(i,j));
      dy_hat(i,j) = dy_hat_temp; 
    end
  end

  %----------------------------------------------------------------------
  % Generate the electric pulse.
  %----------------------------------------------------------------------
  dy = compute_pulse(dy,T,pulse);  

  %----------------------------------------------------------------------
  % Determine the Ey field from Dy. Update Iy and Sy.
  %--------------------d--------------------------------------------------
  ey = ga.*(dy - iy - sy); 

  % Set appropriate Ey edges to 0 as part of the PML. 
  ey(1,:) = 0; ey(Nx,:) = 0; ey(:,1) = 0; %ey(:,Nz) = 0;

  iy = iy + gb.*ey;

  sy = update_s_debye_TM(sy,ey,medium);

  %----------------------------------------------------------------------
  % Determine the Hx and Hz fields from Ey.
  %----------------------------------------------------------------------
  for i = 1:Nx-1
    for j = 1:Nz-1

      % Compute Hz.
      curl_e = ey(i+1,j) - ey(i,j);
      ihz(i,j) = ihz(i,j) + gj1(j)*curl_e;  % Necessary for PMLs.   
      hz(i,j) = fi3(i)*hz(i,j) + fi2(i)*.5*curl_e + fi2(i)*ihz(i,j);

      % Compute Hx.
      curl_e = ey(i,j) - ey(i,j+1);
      ihx(i,j) = ihx(i,j) + gi1(i)*curl_e;  % Necessary for PMLs.
      hx(i,j) = fj3(j)*hx(i,j) + fj2(j)*.5*curl_e + fj2(j)*ihx(i,j);
    end
  end    

  %----------------------------------------------------------------------
  % Output information.
  %----------------------------------------------------------------------
  if output == 1 %%& ceil(T/10) == T/10
    figure(1)
     subplot(211)
      imagesc(ey); hold on
      text(Nx/6,3*Nz/4,.5,['t = ' num2str(n)],'fontsize',18),
      hold off;
      pause(0.1)
     subplot(212)
      plot(ey(Nx/2,:))
%    figure(2)
%     subplot(211)
%       plot(ey(Nx/2,:))
%     subplot(212)
%       plot(ey(Nx/2,Mstart:Nz))
  end

end

