%  fd2d_TE_1.m
%
%  This is the code for Chapter 3.
%
%  This is a 2D EM simulation.
%
%  This is a matlab version of code found in 
%  "Electromagnetic Simulation Using the FDTD Method",
%  Dennis M. Sullivan, IEEE Press Series on RF and 
%  Microwave Technology, 2000. 
%
%  For the c code version see the text.

cpu_t0 = cputime;

%------------------------------------------------------------------------
% Initialization vectors and parameters.
%------------------------------------------------------------------------
KE     = 100;                        % Number of grid points.
kc     = KE/2;                     
ex     = zeros(KE,KE);               % Electric field vector E_x.
ez     = zeros(KE,KE);               % Electric field vector E_z.
dx     = zeros(KE,KE);               % Electric flux vector D_x.
dz     = zeros(KE,KE);               % Electric flux vector D_z.
idx    = zeros(KE,KE);               % Storage vector.     
idz    = zeros(KE,KE);               % Storage vector.
hy     = zeros(KE,KE);               % Magnetic field vector.
hy_hat = zeros(KE,KE);               % Storage vector.
sx     = zeros(KE,KE);               % Medium vector.
sz     = zeros(KE,KE);               % Medium vector.
ix     = zeros(KE,KE);               % Storage vector.
iz     = zeros(KE,KE);               % Storage vector.

%------------------------------------------------------------------------
% Determine step sizes ddx and dt.
%------------------------------------------------------------------------
ddx = .01; %input('Enter cell size. 1cm=.01. PROBLEM DEPENDENT! : ');
dt = ddx/6e8;                     % Calculate the time step size, Eqn. (1.7).

%------------------------------------------------------------------------
% Get necessary PML parameters and vectors.
%------------------------------------------------------------------------
[gi1,gi2,gi3,gj1,gj2,gj3,fi2,fi3,fj2,fj3] = get_pml(KE); 

%------------------------------------------------------------------------
% Get necessary medium parameters and vectors.
%------------------------------------------------------------------------
[ga,gb,gbc,medium] = medium_params_debye(KE,dt);

%------------------------------------------------------------------------
% Get electric pulse information.
%------------------------------------------------------------------------
[I,pulse_params] = get_pulse(KE,dt);

%------------------------------------------------------------------------
% Initialize variables.
%------------------------------------------------------------------------
T = 0;                           % Initialize time step.
show_output = 1; %input('Enter 1 for plot at each iteration; 0 otherwise: ');
NSTEPS = 500;                   % Number of time steps.

%------------------------------------------------------------------------
%------------------------------------------------------------------------
% MAIN FDTD LOOP.
%------------------------------------------------------------------------
%------------------------------------------------------------------------

for n = 1:NSTEPS

  T = T + 1;

  %----------------------------------------------------------------------
  % Determine the Hy field from Ex and Ez.
  %----------------------------------------------------------------------
  for i = 2:KE
    for j = 2:KE
      hy_hat_temp = gi3(i)*hy_hat(i,j) + gi2(i)*.5*...
                        (ez(i,j)-ez(i-1,j)-ex(i,j)+ex(i,j-1));
      hy(i,j) = gj3(j)*hy(i,j) + gj2(j)*(hy_hat_temp - hy_hat(i,j));
      hy_hat(i,j) = hy_hat_temp; 
      % This equation is what is in the book.
      %hy(i,j) = gi3(i)*gj3(j)*hy(i,j) + gi2(i)*gj2(j)*.5*...
      %                     (ez(i,j)-ez(i-1,j)-ex(i,j)+ex(i,j-1));
    end
  end

  %----------------------------------------------------------------------
  % Determine the Dx and Dz fields from Hy.
  %----------------------------------------------------------------------
  for i = 1:KE-1
    for j = 1:KE-1

      % Compute Dz.
      curl_h = hy(i+1,j) - hy(i,j);
      idz(i,j) = idz(i,j) + gj1(j)*curl_h;
      dz(i,j) = fi3(i)*dz(i,j) + fi2(i)*.5*curl_h + fi2(i)*idz(i,j);
      % This eqn. is what is in the book.
      %dz(i,j) = fi3(i)*dz(i,j) + fi2(i)*.5*(curl_h + idz(i,j));

      % Compute Dx.
      curl_h = hy(i,j) - hy(i,j+1);
      idx(i,j) = idx(i,j) + gi1(i)*curl_h;
      dx(i,j) = fj3(j)*dx(i,j) + fj2(j)*.5*curl_h + fj2(j)*idx(i,j);
      % This eqn. is what is in the book.
      %dx(i,j) = fj3(j)*dx(i,j) + fj2(j)*.5*(curl_h + idx(i,j));
    end
  end    

  %----------------------------------------------------------------------
  % Generate the electric pulse.
  %----------------------------------------------------------------------
  pulse = compute_pulse(T,pulse_params);  

  dx(I) =  dx(I) + pulse;

  %----------------------------------------------------------------------
  % Determine the Ex and Ez fields from Dx and Dz.
  %--------------------d--------------------------------------------------
  ex = ga.*(dx - ix - sx); 
  ez = ga.*(dz - iz - sz); 
  ix = ix + gb.*ex;
  iz = iz + gb.*ez;  

  % Set Ez edges to 0 as part of the PML. This is done in the book.
  %ez(1,:) = 0;
  %ez(KE,:) = 0; 
  %ez(:,1) = 0;
  %ez(:,KE) = 0;

  [sx,sz] = update_s_debye(sx,sz,ex,ez,medium);

  %----------------------------------------------------------------------
  % Output information.
  %----------------------------------------------------------------------
  if show_output == 1
    figure(1)
      imagesc(ex); hold on
      text(KE/4,KE/4,.5,['t = ' num2str(n)],'fontsize',18),
      hold off;
      pause(0.1)
    figure(2)
     plot(ex(KE/2,:))
  end

end

fprintf('TOTAL CPU TIME: %5.5e\n',cputime-cpu_t0);


