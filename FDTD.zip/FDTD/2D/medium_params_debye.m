  function[ga,gb,gbc,medium] = medium_params_debye(KE,dt)

% In this m-file we create the parameters that characterize the medium.

%------------------------------------------------------------------------
% Input dielectric constant vector and location of dielectric. 
%------------------------------------------------------------------------
epsilon_0 = 8.8e-12;             % Permittivity of free space.
epsilon_r = 5; %input('Enter the permittivity epsilon_r = '); 
epsilon_r_vec = ones(KE,KE);
dstart = input('Enter the z-coord of dielectric interface: ');
epsilon_r_vec(:,dstart:KE) = epsilon_r*epsilon_r_vec(:,dstart:KE);

%------------------------------------------------------------------------
% Input the conductivity. Ohmic conductivity: J = sigma*E.
%------------------------------------------------------------------------
sigma = .01; %input('Enter the conductivity sigma = ');
sigma_vec = zeros(KE,KE);
sigma_vec(:,dstart:KE) = sigma_vec(:,dstart:KE) + sigma;
back_bound = 0; %input('Enter 1 for metal back boundary and 0 otherwise: ');
if back_bound == 1
  sigma_vec(:,KE) = 1e6;           % To simulate a metal back boundary
end

%------------------------------------------------------------------------
% Debye parameters
%------------------------------------------------------------------------
epsilon_s = 35;
epsilon_d = epsilon_s - epsilon_r;
chi_1 = epsilon_d;
tau_0 = 1e-5; %input('Input Debye parameter tau (in microseconds): '); 
tau_0 = 1e-6*tau_0;
model_choice = 1;% input('Enter 1 for auxilliary ODE and 0 otherwise: ');

%------------------------------------------------------------------------
% Determine necessary vectors and constants. See (2.23)
%------------------------------------------------------------------------
gb = (dt*sigma_vec)./epsilon_0;
gbc = zeros(KE,KE);
gbc(:,dstart:KE) = gbc(:,dstart:KE) + chi_1*dt/tau_0;
ga = 1./(epsilon_r_vec + gb + gbc);

%------------------------------------------------------------------------
% Save the parameters necessary for later calculations
%------------------------------------------------------------------------

medium.del_exp      = exp(-dt/tau_0);
medium.tau_0        = tau_0;
medium.gbc          = gbc;
medium.dt           = dt;
medium.model_choice = model_choice;
