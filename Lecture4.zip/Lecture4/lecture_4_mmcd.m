%% Simulation and Differential Equations
%
% Many physical systems can be described by differential equations.  The
% defining characteristic of these systems is we can describe the
% infinitesimal evolution of the system even though we may be unable to
% solve the full evolution of the system in closed form.  For systems where
% the analytical solution is unobtainable numerical methods can be used to
% determine the evolution of the system.
%
% In this lecture various forms of differential equations and
% ways to simulate their behaviour are discussed:
%
% * symbolic manipulation of equations
% * initial value problems
% * chaotic systems
% * central potentials

%% Symbolic Computation from the MATLAB command line
%
% The Symbolic Toolbox contains a Computer Algebra System that allows
% equations to be manipulated symbolically.  This can be accessed through
% the MATLAB command line or through the separate MuPad interface (the
% latter is new in R2008b).  Let's start with the MATLAB command line:

% Define a symbolic variable in the MATLAB workspace
syms x;
% Create an expression using this symbol
f = x^2;
% We can substitute numerical values into this expression
subs(f,x,2)
% We can also substitute in other symbols and expand the result, save this
% as a new expression
syms a b;
s = expand(subs(f,x,a+b)) %#ok<NOPTS>
% ... and use factor to get the original form back
factor(s)

%% Plotting symbolic expressions in MATLAB

% We can also plot a symbolic expression (see help ezplot or doc ezplot 
% for more plotting functions)
ezplot(f,[0 10])

% Most of the MATLAB visualisation functions work on a vector of doubles,
% so if we want to use these we need to evaluate the expression over a
% range of values to return a numerical vector.

% Create a variable containing the range of values over which we want to 
% evaluate f.  This is a standard MATLAB vector of double precision numbers.
xVector = linspace(0,10,1000)';

% Substitute this vector of range values into the expression and plot the
% result
fValues = subs(f,x,xVector);
figure;
plot(xVector,fValues,'b-');

%% Plot the tangent to a curve
% Find the derivative of the expression (x is the default symbolic
% variable)

fdiff = diff(f);
% Use the derivative to plot the tangent to the curve at x=2
tangentExpr = subs(f,x,2) + (x-2)*subs(fdiff,x,2);
% Plot the curve and the tangent at x=2
tangentValues = subs(tangentExpr,x,xVector);
plot(xVector,fValues,'b-',xVector,tangentValues,'r--');

%% Turn this into a general function

% Construct the tangent expression at point x=x0 for expression f(x)
tangentExpr = @(f,x0) subs(f,x,x0) + (x-x0)*subs(diff(f),x,x0);
% Plot the function and the derivative
plotDeriv = @(f,x0,xRange) ...
    plot(xRange,subs(f,x,xRange),'b-',...
    xRange,subs(tangentExpr(f,x0),xRange),'r--');

% Try out the general function
plotDeriv(sin(x),1,0:0.1:5)

%% Plot the family of tangents to the curve y=x^2.  
% This is related to the Legendre Transformation that you will cover in 
% statistical physics and classical mechanics.

% Define the points where we want to construct the tangent to the curve
tangentPoints = 1:10;
% Define the points where we will evaluate the function and the tangent
% curves for plotting
xVector = linspace(0,10,1000)';

% Evaluate the function that creates the tangent
% expression at a given point for each point where we want to construct a
% tangent to the curve.  
% 
% For each of these expressions substitute the range of variables used 
% for the plot range.  
%
% Return the overall result as a cell array where each element is a column
% vector of doubles.  
%
% Use cell2mat to convert this into a matrix where each column is the 
% y values for a different tangent curve.

tangentLines = cell2mat(...
    arrayfun(@(x0) subs(tangentExpr(x^2,x0),x,xVector),tangentPoints,...
    'UniformOutput',false));

% Create the vector of function values
fValues = subs(x^2,x,xVector);
% Plot everything and keep the handles to the lines plotted
h=plot(xVector,tangentLines,'r-',xVector,fValues,'b-');
% Make the function curve wider than the tangent lines
set(h(end),'Linewidth',4)

%% The MuPad notebook interface
% Open the muPad file for this lecture
% nb = mupad('lecture_4_mmcd_mupad.mn');

image(imread('MuPAD_pic.png')); axis equal; axis off;
% The symbolic toolbox is a useful tool to check that you are on the right
% track during a derivation but you still need to be able to perform these
% by hand.  The reason is that you need to have an intuitive feel of how
% the equations and symbols are manipulated, in order to know which
% simplifications to try and avoid wrong steps.

%% Initial value problems
%
% Initial value problems are commonly encountered in descriptions of
% system dynamics.  The defining feature of these problems is the initial
% state and the equations governing the evolution of the system over an
% infintesimal time step are known.  
%
% The MATLAB differential equation solvers require first order differential 
% equations, higher order differential equations must be rephrased as first
% order differential equations in a higher number of dimesnions.  For
% example the harmonic oscillator equations of motion $m\ddot{x}=-kx$ 
% need to be rephrased as 
%
% $v=\dot{x}, [\dot{x}; \dot{v}]=[0\  1;\  -k/m\  0]*[x;v]$


%% Finite differences - Euler method
%
% Simulating the evolution of an intial value problem involves solving
% numerically the equation $y^{\prime} = f\left(t,y\right)$.  The goal is
% to find the state of the system after timestep $h$ given the state at
% time $t$.  Using the Taylor expansion we have
%
% $y(t+h) \approx y(t) + h*y^{\prime}(t)$
%
% i.e. the approximation to the position at the next time step is given by
% the gradient of the evolution function at the current position and the
% time step size.  The accuracy of this method is improved by reducing the
% time step size, with the trade-off that this also increases the
% computation term.  Other approaches improve accuracy by using more
% information about the evolution function to estimate the position at the
% next step.
%
% As an example, we will use the Euler method to simulate projectile
% motion.  Assuming lack of air resistance we have
% $\ddot{x} = 0$ and $\ddot{h} = -g$, where $g$ is the acceleration due to
% gravity, $x$ is the horizontal position and $h$ is the height.  The
% projectile starts at the origin with speed v0 and angle to the horizontal
% theta0.
%
% Converting to a system of first order equations, the state vector is
% $r = [x; v_x; h; v_h]$, where $v_x=\dot{x}$ is the horizontal velocity 
% and $v_h=\dot{h}$ is the vertical velocity, and the equations of motion are 
% $\dot{r} = [0\ 1\ 0\ 0; 0\ 0\ 0\ 0; 0\ 0\ 0\ 1; 0\ 0\ 0\ 0] + [0;0;0;-g]$

% Set the model parameters for simulation.  Use cell mode to alter the
% value of the time step h and see the effect on the simulation result

% Initial speed
v0 = 1; % m/s
% Angle of projectile
theta0 = pi/3; % radians
% Number of time steps - change this in cell mode to see effect on accuracy
stepCount = 10;
% Gravity
g = 9.81; % m/s^2

% Equations of motion
A = [0 1 0 0; 0 0 0 0; 0 0 0 1; 0 0 0 0];
gVect = [0 0 0 -g]';

% We can solve this system exactly so use the exact solution to set the
% maximum simulation time to be the time when the projectile returns to
% earth.
tMax = 2*v0*sin(theta0)/g;
% Define the time step 
h = tMax/stepCount;
% Exact horizontal and vertical displacement in functional form for plotting
vx0 = v0*cos(theta0); % Initial horizontal velocity
vh0 = v0*sin(theta0); % Initial vertical velocity
xPos = @(t) vx0*t;
hPos = @(t) vh0.*t - 0.5.*g.*t.^2;

% Define the vector of time values
tVals = (0:h:tMax)';
% Preallocate a matrix to store the simulated path
res = zeros(4,numel(tVals));
% Initialise the starting state
res(:,1) = [0; vx0; 0; vh0];
% Do the simulation
for stepIndex = 2:numel(tVals)
    deltaR = h*(A*res(:,stepIndex-1) + gVect);
    res(:,stepIndex) = res(:,stepIndex-1) + deltaR;
end

% Plot the result and the exact solution
plot(xPos(tVals),hPos(tVals),'b-',res(1,:),res(3,:),'r-')
xlabel('Horizontal Position')
ylabel('Height')
title(['Projectile motion.  Timestep = t_{max}/',num2str(stepCount)])
legend('Exact','Simulated')

%% Runge-Kutta method
% A more accurate finite differences method is the Runge-Kutta method, 
% which uses the estimated slope at the current point to predict the 
% location of the next point after timestep 'h' ie
%
% $y_{n+1} = y_n + \frac{h}{6} f\left(k_1 + 2 k_2 + 2 k_3 + k_4\right)$
% 
% $t_{n+1} = t_n + h$
%
% with
%
% $k_1 = f\left(t_n, y_n\right)$
%
% $k_2 = f\left(t_n + h/2, y_n + h/2 k_1\right)$
%
% $k_3 = f\left(t_n + h/2, y_n + h/2 k_2\right)$
%
% $k_4 = f\left(t_n + h, y_n + h k_3\right)$
%
% This method is implemented in the MATLAB function ode45 (which uses an
% adaptive step size that compares the results of the 4th order and 5th
% order methods).

%% Initial value problems - Chaos and Chaotic Systems
%
% Many nonlinear systems can exhibit chaotic behaviour, which occurs when
% the separation between neighbouring points increases exponentially while
% at the same time the system is constrained to lie within a fixed region
% of space.  A famous example of a chaotic system is the Lorentz Attractor
% which models turbulence in the atmosphere.  The solution of this system
% cannot be found analytically, so numerical integration is required to
% investigate the behaviour of the system.
%
% The equations governing the Lorentz Attractor are:
% 
% $\dot{x} = \sigma(y-x)$
%
% $\dot{y} = x(\rho - z) - y$
%
% $\dot{z} = xy - \beta z$
%
% where $\sigma, \beta, \rho$ are parameters of the system.  
% Usually $\sigma = 10, \beta=8/3$ and $\rho$ is varied. 

% Define the evolution equation and the parameters to use.  
% The state vector [x;y;z] is represented by a 3 element column vector x.
% The ODE function itself must take a scalar time value and column vector
% state as input, and return a column vector as output (the new state).
%
lorentzFun = @(s,b,r)...   % A function that takes the parameter values and returns...
    @(t,x) ...             % a function that takes the time and state
    [s*(x(2) - x(1)); ...
     x(1)*(r-x(3))-x(2);...
     x(1)*x(2) - b*x(3)];
%%
% The code above is a function that takes the sigma, beta and rho parameter
% values as an argument and returns an ODE function as the result (that's right 
% - a function can output a new function).  If this is confusing then
% ignore the first @(s,b,r) bit and assume that we defined the variables
% s,b and r somewhere before this function.

%% Use cell mode to try varying the value of rho
% Specify the parameters to use for this simulation.  The parameters
% are given the names sigmaVal etc because there are some built-in MATLAB
% functions called for example beta.  
sigmaVal = 10;
betaVal = 8/3;
% Highlight the value below and press the + or - button in the editor 
rhoVal = 28; % Gives chaotic behaviour for rhoVal = 28

% Specify the starting coordinate
x0 = [0 1 1.05]';
% Specify the maximum simulation time
tMax = 25;

thisODEFun = lorentzFun(sigmaVal,betaVal,rhoVal);
[t,y] = ode45(thisODEFun,[0 tMax],x0);
% Plot the result
% figure('Name','ODE simulation result')
plot3(y(:,1),y(:,2),y(:,3))
 
%% Lorentz attractor object 
 
% Create a LorentzAttractor object
lorAt = LorentzAttractor('x0',[0 1 1.05]);
% Create another object starting at a slightly different position
lorAt2 = LorentzAttractor('x0',[0 1 1.0]);
% Plot both evolutions on the same figure
figure('Name','Lorentz Attractor')
lorAt.plot3
hold on
lorAt2.plot3('r')


%% Case Study: Motion in central potentials
%
% Central potentials arise in a number of areas of physics, such as
% orbital mechanics and particle scattering.  A central potential between
% two particles is one that only depends on the distance between the
% particles, not their relative orientation.

simType = 'gravitational';

% Choose the simulation type
switch lower(simType)
    case 'gravitational'
        % Particle masses
        charges = [1 1 1]';
        masses = [1 1 1]';
        x0 = [0 3 0]';
        y0 = [0 0 4]';
        vx0 = [0 0 0]';
        vy0 = [0 0 0]';
        polarity = 1;
    case 'scattering'
        charges = [1 1]';
        masses = [1 1]';
        x0 = [-10 10]';
        y0 = [-1 1]';
        vx0 = [1 -1]';
        vy0 = [0 0]';
        polarity = -1;
    otherwise
        error('Unknown simulation type')
end

odeFun = @(t,x) centralPotentialODE(x,charges,2,polarity,masses);

tMax = 100;
options = odeset('reltol',1e-9,'abstol',1e-9);
[t,y] = ode45(odeFun,[0 tMax],[x0; y0; vx0; vy0],options);

% Number of particles that we are simulating
chargeCount = numel(masses);

% Extract the elements of the state vector corresponding to the x and y
% coordinates of the particles
xPath = y(:,1:chargeCount);
yPath = y(:,chargeCount + (1:chargeCount));

% Calculate the coordinates of the centre of mass
xCoM = xPath*masses/sum(masses);
yCoM = yPath*masses/sum(masses);

% Plot the particle paths and return a handle to the plot lines
figHandle = figure;
plotPanel = uipanel('Parent',figHandle,'Units','Normalized',...
    'Position',[0 0.1 1 0.9]);
plotAxes = axes('Parent',plotPanel);
h = plot(plotAxes,xPath,yPath,'-',xCoM,yCoM,'.',x0,y0,'ko');
drawnow
axis manual
title('Central potential motion')

% Create a slider to manipulate how much of path to show
sliderPanel = uipanel('Parent',figHandle,'Units','Normalized',...
    'Position',[0 0 1 0.1]);
sliderHandle = uicontrol('Parent',sliderPanel,'Units','Normalized',...
    'Position',[0 0 1 1],'style','slider','Min',0,'Max',tMax,...
    'SliderStep',[1e-3 1e-2],'Value',0,...
    'Callback',@(s,e) selectPathData(h,xPath,yPath,t,get(s,'Value')));
    
%   Copyright 2008-2009 The MathWorks Ltd
%   $Revision: 28 $  $Date: 2009-02-17 18:02:08 +0000 (Tue, 17 Feb 2009) $