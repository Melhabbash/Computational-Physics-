function selectPathData(h,x,y,t,tSet,rangeFraction)
% selectPathData : only display a section of a particle path
% h is array of line handles to plotted paths
% x and y are the M*N matrices of all path values
% t is a M*1 vector of the path times
% tSet is the maximum time to plot
% rangeFraction is the fraction of the path to plot

%   Copyright 2008-2009 The MathWorks Ltd
%   $Revision: 28 $  $Date: 2009-02-17 18:02:08 +0000 (Tue, 17 Feb 2009) $

% Number of particles is number of columns of x or y
particleCount = size(x,2);

% Maximum time
tMax = max(t);

% Show at most rangeFraction of total time range
if nargin<6
    rangeFraction = 0.1;
end
tRange = rangeFraction*tMax;

% Indices of the particle paths in the time range to plot
pathIndex = (t > (tSet - tRange)) & (t <= tSet);

for lineIndex = 1:particleCount
    set(h(lineIndex),'XData',x(pathIndex,lineIndex),...
        'YData',y(pathIndex,lineIndex),'LineWidth',2);
end